<?php
require_once 'koneksi.php';

// Ambil ekskul secara dinamis
$sqlEkskul = "SELECT id, kode_ekskul, nama_ekskul, keterangan FROM tbl_ekskul ORDER BY id ASC";
$resEkskul = $conn->query($sqlEkskul);
$listEkskul = [];
$ekskulMap = [];
$idx = 1;
if ($resEkskul) {
    while($r = $resEkskul->fetch_assoc()) {
        $listEkskul[$idx] = $r;
        $ekskulMap[$idx] = $r['nama_ekskul'];
        $idx++;
    }
}
$K = count($listEkskul);

// Hitung sebaran siswa per cluster
$clusterCounts = array_fill(1, $K, 0);
$resCluster = $conn->query("SELECT cluster, COUNT(*) as jml FROM tbl_siswa GROUP BY cluster");
if ($resCluster) {
    while($row = $resCluster->fetch_assoc()) {
        $c = intval($row['cluster']);
        if (isset($clusterCounts[$c])) {
            $clusterCounts[$c] = intval($row['jml']);
        }
    }
}

// Ambil data siswa
$sqlSiswa = "SELECT id, nama, jkel, cluster, var1, var2, var3, var4, var5 FROM tbl_siswa ORDER BY id ASC";
$resSiswa = $conn->query($sqlSiswa);
$dataPoints = [];
if ($resSiswa) {
    while($row = $resSiswa->fetch_assoc()) {
        $c = intval($row['cluster']);
        $row['nama_ekskul'] = $ekskulMap[$c] ?? "Ekskul $c";
        $row['keterangan'] = $listEkskul[$c]['keterangan'] ?? "-";
        $dataPoints[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Hasil Clustering Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .card-stat { transition: transform 0.2s ease, box-shadow 0.2s ease; }
        .card-stat:hover { transform: translateY(-2px); box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); }
    </style>
</head>
<body class="bg-gray-50 text-gray-800">
    <div class="min-h-screen container mx-auto px-4 py-8">
        
        <!-- Header -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
            <div class="bg-gradient-to-r from-blue-600 to-indigo-700 px-6 py-5">
                <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center text-white text-2xl">
                            <i class="fas fa-project-diagram"></i>
                        </div>
                        <div>
                            <h1 class="text-2xl font-bold text-white">Data Hasil Clustering Siswa</h1>
                            <p class="text-blue-100 text-sm">Pengelompokan Otomatis Menyesuaikan Total Ekstrakurikuler Aktif (K = <?= $K ?>)</p>
                        </div>
                    </div>
                    <nav class="flex space-x-2">
                        <a href="iterasi.php" class="px-4 py-2 rounded-lg bg-purple-500 hover:bg-purple-600 text-white font-medium text-sm transition flex items-center shadow">
                            <i class="fas fa-database mr-2"></i> Log Iterasi
                        </a>
                        <a href="laporan_cluster.php" class="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-sm transition flex items-center">
                            <i class="fas fa-file-alt mr-2"></i> Laporan
                        </a>
                        <a href="dashboard.php" class="px-4 py-2 rounded-lg bg-white text-blue-700 hover:bg-blue-50 font-semibold text-sm transition shadow flex items-center">
                            <i class="fas fa-home mr-2"></i> Beranda
                        </a>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Kartu Ringkasan Informasi Kluster Dinamis -->
        <div class="mb-6">
            <div class="flex items-center justify-between mb-3">
                <h2 class="text-lg font-bold text-gray-700 flex items-center">
                    <i class="fas fa-info-circle text-blue-600 mr-2"></i> Informasi & Penilaian Kluster (Dinamis: Cluster 1 s/d <?= $K ?>)
                </h2>
                <span class="text-xs text-gray-600 bg-gray-200 px-3 py-1 rounded-full font-semibold">Tersinkronisasi dengan Data Ekskul</span>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-<?= min($K, 5) ?> gap-4">
                <?php 
                $colors = ['red', 'orange', 'amber', 'indigo', 'green', 'teal', 'cyan', 'rose'];
                foreach($listEkskul as $cIndex => $ek): 
                    $color = $colors[($cIndex - 1) % count($colors)];
                ?>
                    <div class="card-stat bg-white rounded-xl p-4 border-t-4 border-<?= $color ?>-500 shadow-sm">
                        <div class="flex justify-between items-start mb-2">
                            <span class="px-2 py-0.5 text-xs font-bold rounded bg-<?= $color ?>-50 text-<?= $color ?>-700 border border-<?= $color ?>-200">
                                Cluster <?= $cIndex ?>
                            </span>
                            <span class="font-mono text-xs text-gray-400"><?= $ek['kode_ekskul'] ?></span>
                        </div>
                        <h3 class="font-bold text-gray-800 text-base"><?= htmlspecialchars($ek['nama_ekskul']) ?></h3>
                        <p class="text-xs text-gray-500 mt-1 line-clamp-2"><?= htmlspecialchars($ek['keterangan']) ?: 'Kegiatan pembinaan minat bakat' ?></p>
                        <div class="mt-3 pt-2 border-t border-gray-100 flex justify-between items-center text-xs">
                            <span class="text-gray-500">Anggota:</span>
                            <span class="font-bold text-<?= $color ?>-600 text-sm"><?= $clusterCounts[$cIndex] ?? 0 ?> Siswa</span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Tabel Hasil Clustering -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
            <div class="p-6 border-b border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4">
                <div>
                    <h3 class="text-lg font-bold text-gray-800">Tabel Hasil Rekomendasi Ekstrakurikuler Siswa</h3>
                    <p class="text-sm text-gray-500">Hasil pengelompokan K-Means berdasarkan penilaian kuisioner minat bakat</p>
                </div>
                <div class="flex items-center space-x-3 w-full md:w-auto">
                    <div class="relative flex-1 md:w-64">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                            <i class="fas fa-search"></i>
                        </span>
                        <input type="text" id="searchInput" placeholder="Cari nama atau cluster..." class="w-full pl-9 pr-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <select id="filterCluster" class="py-1.5 px-3 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
                        <option value="">Semua Cluster</option>
                        <?php foreach($listEkskul as $cIndex => $ek): ?>
                            <option value="<?= $cIndex ?>">Cluster <?= $cIndex ?> (<?= htmlspecialchars($ek['nama_ekskul']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table id="studentsTable" class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase">ID</th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase">Nama Siswa</th>
                            <th class="px-5 py-3.5 text-center text-xs font-semibold text-gray-600 uppercase">Gender</th>
                            <th class="px-5 py-3.5 text-center text-xs font-semibold text-gray-600 uppercase">Cluster</th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase">Rekomendasi Ekstrakurikuler</th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase">Keterangan Ekskul</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200 text-sm">
                        <!-- Disuntikkan JS -->
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="px-6 py-4 bg-gray-50 border-t border-gray-200">
                <div class="flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div class="text-sm text-gray-600">
                        Menampilkan <span id="startItem" class="font-semibold text-gray-800">0</span> sampai <span id="endItem" class="font-semibold text-gray-800">0</span> dari <span id="totalItems" class="font-semibold text-gray-800">0</span> data
                    </div>
                    <div class="flex space-x-2">
                        <button id="refreshButton" class="px-3.5 py-1.5 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-700 font-medium text-sm transition flex items-center shadow-sm">
                            <i class="fas fa-sync-alt mr-1.5 text-blue-600"></i> Proses Ulang K-Means Dinamis
                        </button>
                        <button id="prevPage" class="px-3.5 py-1.5 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-700 font-medium text-sm transition disabled:opacity-40 disabled:cursor-not-allowed shadow-sm">
                            <i class="fas fa-chevron-left mr-1"></i> Sebelumnya
                        </button>
                        <button id="nextPage" class="px-3.5 py-1.5 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-700 font-medium text-sm transition disabled:opacity-40 disabled:cursor-not-allowed shadow-sm">
                            Selanjutnya <i class="fas fa-chevron-right ml-1"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const rawStudents = <?php echo json_encode($dataPoints); ?>;
        let filteredStudents = [...rawStudents];
        let currentPage = 1;
        const itemsPerPage = 15;
        
        const studentsTable = document.getElementById('studentsTable').getElementsByTagName('tbody')[0];
        const prevPageBtn = document.getElementById('prevPage');
        const nextPageBtn = document.getElementById('nextPage');
        const startItemSpan = document.getElementById('startItem');
        const endItemSpan = document.getElementById('endItem');
        const totalItemsSpan = document.getElementById('totalItems');
        const searchInput = document.getElementById('searchInput');
        const filterCluster = document.getElementById('filterCluster');
        const refreshBtn = document.getElementById("refreshButton");

        refreshBtn.addEventListener("click", function() {
            refreshBtn.disabled = true;
            refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1.5"></i> Memproses K-Means...';
            fetch('kmeans.php')
                .then(r => r.json())
                .then(data => {
                    alert('Berhasil! ' + data.message + ' (K = ' + data.k + ', ' + data.iterations + ' Iterasi)');
                    window.location.reload();
                })
                .catch(err => {
                    console.error(err);
                    window.location.reload();
                });
        });

        prevPageBtn.addEventListener('click', () => { if(currentPage > 1) { currentPage--; renderTable(); } });
        nextPageBtn.addEventListener('click', () => { const totalP = Math.ceil(filteredStudents.length / itemsPerPage); if(currentPage < totalP) { currentPage++; renderTable(); } });
        searchInput.addEventListener('input', applyFilters);
        filterCluster.addEventListener('change', applyFilters);

        function applyFilters() {
            const query = searchInput.value.toLowerCase().trim();
            const selectedC = filterCluster.value;

            filteredStudents = rawStudents.filter(s => {
                const matchQuery = (s.nama && s.nama.toLowerCase().includes(query)) || (s.id && s.id.toString().includes(query));
                const matchC = selectedC === "" || s.cluster.toString() === selectedC;
                return matchQuery && matchC;
            });
            currentPage = 1;
            renderTable();
        }

        function renderTable() {
            studentsTable.innerHTML = '';
            const total = filteredStudents.length;
            const totalPages = Math.ceil(total / itemsPerPage) || 1;
            const start = (currentPage - 1) * itemsPerPage;
            const end = Math.min(start + itemsPerPage, total);

            startItemSpan.textContent = total > 0 ? start + 1 : 0;
            endItemSpan.textContent = end;
            totalItemsSpan.textContent = total;

            prevPageBtn.disabled = currentPage <= 1;
            nextPageBtn.disabled = currentPage >= totalPages;

            const slice = filteredStudents.slice(start, end);
            if (slice.length === 0) {
                const r = studentsTable.insertRow();
                const c = r.insertCell(0);
                c.colSpan = 6;
                c.className = "px-6 py-8 text-center text-gray-500";
                c.innerHTML = '<i class="fas fa-info-circle mr-2"></i> Tidak ada data siswa yang cocok.';
                return;
            }

            slice.forEach(s => {
                const row = studentsTable.insertRow();
                row.className = "hover:bg-blue-50/50 transition";

                row.insertCell(0).className = "px-5 py-3.5 font-medium text-gray-900";
                row.cells[0].textContent = s.id;

                row.insertCell(1).className = "px-5 py-3.5 font-bold text-gray-900";
                row.cells[1].textContent = s.nama;

                const cJkel = row.insertCell(2);
                cJkel.className = "px-5 py-3.5 text-center";
                cJkel.innerHTML = s.jkel === 'L' ? '<span class="text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full text-xs font-medium">Laki-laki</span>' : '<span class="text-pink-700 bg-pink-50 px-2.5 py-0.5 rounded-full text-xs font-medium">Perempuan</span>';

                const cClust = row.insertCell(3);
                cClust.className = "px-5 py-3.5 text-center";
                cClust.innerHTML = `<span class="bg-purple-100 text-purple-800 font-bold px-3 py-1 rounded-full text-xs">Cluster ${s.cluster}</span>`;

                const cEks = row.insertCell(4);
                cEks.className = "px-5 py-3.5 font-bold text-indigo-900";
                cEks.textContent = s.nama_ekskul;

                const cKet = row.insertCell(5);
                cKet.className = "px-5 py-3.5 text-xs text-gray-600 max-w-sm break-words";
                cKet.textContent = s.keterangan || '-';
            });
        }

        renderTable();
    </script>
</body>
</html>
