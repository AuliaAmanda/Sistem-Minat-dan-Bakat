<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "skripsi";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Koneksi database gagal: " . $conn->connect_error]);
    exit;
}

$iddata = intval($_POST['id_ekskul'] ?? 0);
$kode_ekskul = trim($_POST['kode_ekskul'] ?? '');
$nama_ekskul = trim($_POST['nama_ekskul'] ?? '');
$jml_anggota = intval($_POST['jml_anggota'] ?? 0);
$nama_pelatih = trim($_POST['nama_pelatih'] ?? '');
$keterangan = trim($_POST['keterangan'] ?? '');

if ($iddata <= 0 || $kode_ekskul === '' || $nama_ekskul === '') {
    echo json_encode(["status" => "error", "message" => "ID, Kode, dan Nama Ekskul wajib valid"]);
    $conn->close();
    exit;
}

$stmt = $conn->prepare("UPDATE tbl_ekskul SET kode_ekskul = ?, nama_ekskul = ?, jml_anggota = ?, nama_pelatih = ?, keterangan = ? WHERE id = ?");
$stmt->bind_param("ssissi", $kode_ekskul, $nama_ekskul, $jml_anggota, $nama_pelatih, $keterangan, $iddata);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success", 
        "message" => "Data ekstrakurikuler berhasil diperbarui"
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal memperbarui: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
