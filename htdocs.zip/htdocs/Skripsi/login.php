    <?php
    // update_data.php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "skripsi";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);
    //print_r($data);

    //$nama = $_POST['user'] ?? ''; // Example: assuming 'name' field from form
    //$pwd = $_POST['pwd'] ?? ''; // Example: assuming 'email' field from form
   
    $sql = "SELECT id FROM tbl_users where username = '" . $data['user'] . "' and password = '" . $data['pwd'] . "'" ; // Select specific columns
    //echo $sql;

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "1";
    } else {
        echo "0";
    } 

    ?>