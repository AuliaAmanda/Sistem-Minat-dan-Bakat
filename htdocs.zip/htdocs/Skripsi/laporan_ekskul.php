<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "skripsi";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT id, kode_ekskul, nama_ekskul, jml_anggota, nama_pelatih, keterangan FROM tbl_ekskul ORDER BY id ASC";
$result = $conn->query($sql);
$dataPoints = [];
$totalAnggota = 0;

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $dataPoints[] = $row;
        $totalAnggota += intval($row['jml_anggota']);
    }
}
$totalEkskul = count($dataPoints);
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Data Ekstrakurikuler - Sistem Manajemen Ekskul</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @media print {
            .no-print { display: none !important; }
            body { margin: 0; padding: 0; background: white; color: black; font-size: 11pt; }
            .print-container { box-shadow: none !important; border: none !important; padding: 0 !important; width: 100% !important; max-width: 100% !important; }
            table { page-break-inside: auto; }
            tr { page-break-inside: avoid; page-break-after: auto; }
            thead { display: table-header-group; }
        }
        .print-container { max-width: 210mm; margin: 0 auto; }
    </style>
</head>
<body class="bg-gray-100 p-4 sm:p-6 text-gray-800">
    
    <!-- Action Bar (No Print) -->
    <div class="no-print max-w-[210mm] mx-auto mb-4 flex flex-wrap justify-between items-center bg-white p-4 rounded-xl shadow-sm border border-gray-200 gap-3">
        <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-emerald-600"></span>
            <span class="text-sm font-bold text-gray-700">Laporan Rekapitulasi Data Ekstrakurikuler & Pembina</span>
        </div>
        <div class="flex space-x-2">
            <button onclick="window.print()" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition shadow flex items-center">
                <i class="fas fa-print mr-2"></i> Cetak / Simpan PDF
            </button>
            <button onclick="exportTableToExcel('tabelDataEkskul', 'Laporan_Data_Ekstrakurikuler')" class="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition shadow flex items-center">
                <i class="fas fa-file-excel mr-2"></i> Ekspor Excel
            </button>
            <a href="data_ekskul.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold transition flex items-center">
                <i class="fas fa-arrow-left mr-2"></i> Kembali
            </a>
        </div>
    </div>

    <!-- Printable Paper Sheet -->
    <div class="print-container bg-white p-10 rounded-xl shadow-lg border border-gray-200">
        
        <!-- Kop Surat Resmi -->
        <div class="border-b-4 border-double border-gray-800 pb-4 mb-6 text-center">
            <h2 class="text-xl font-bold uppercase tracking-wider text-gray-900">SISTEM PENDUKUNG KEPUTUSAN MINAT & BAKAT SISWA</h2>
            <h1 class="text-2xl font-black uppercase text-emerald-900 tracking-tight mt-0.5">LAPORAN REKAPITULASI PROGRAM EKSTRAKURIKULER</h1>
            <p class="text-xs text-gray-600 mt-1">Daftar Kegiatan Ekstrakurikuler, Pembina/Pelatih, Kuota dan Deskripsi Program</p>
        </div>

        <!-- Meta Info -->
        <div class="flex justify-between items-center text-xs text-gray-600 mb-6 border-b border-gray-200 pb-3">
            <div>
                <p><strong>Total Program:</strong> <?= $totalEkskul ?> Kegiatan Ekstrakurikuler</p>
                <p><strong>Total Anggota Terdaftar:</strong> <?= $totalAnggota ?> Siswa</p>
            </div>
            <div class="text-right">
                <p><strong>Tanggal Dokumen:</strong> <?= date('d F Y') ?></p>
                <p><strong>Status Program:</strong> Aktif Tahun Ajaran Berjalan</p>
            </div>
        </div>

        <!-- Tabel Detail Ekskul -->
        <div class="mb-8">
            <table id="tabelDataEkskul" class="w-full border-collapse border border-gray-300 text-xs">
                <thead>
                    <tr class="bg-gray-100 text-gray-700">
                        <th class="border border-gray-300 p-2 text-center w-12">No</th>
                        <th class="border border-gray-300 p-2 text-center w-20">Kode</th>
                        <th class="border border-gray-300 p-2 text-left w-36">Nama Ekstrakurikuler</th>
                        <th class="border border-gray-300 p-2 text-center w-24">Jumlah Anggota</th>
                        <th class="border border-gray-300 p-2 text-left w-44">Nama Pelatih / Pembina</th>
                        <th class="border border-gray-300 p-2 text-left">Keterangan Program</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($dataPoints)): ?>
                        <?php foreach($dataPoints as $index => $row): ?>
                            <tr class="<?= $index % 2 == 1 ? 'bg-gray-50/50' : 'bg-white' ?>">
                                <td class="border border-gray-300 p-2 text-center"><?= $index + 1 ?></td>
                                <td class="border border-gray-300 p-2 text-center font-mono font-semibold text-emerald-800"><?= $row['kode_ekskul'] ?></td>
                                <td class="border border-gray-300 p-2 font-bold text-gray-900"><?= htmlspecialchars($row['nama_ekskul']) ?></td>
                                <td class="border border-gray-300 p-2 text-center font-semibold"><?= $row['jml_anggota'] ?> Siswa</td>
                                <td class="border border-gray-300 p-2 text-gray-800"><?= htmlspecialchars($row['nama_pelatih']) ?></td>
                                <td class="border border-gray-300 p-2 text-gray-600"><?= htmlspecialchars($row['keterangan']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="border border-gray-300 p-4 text-center text-gray-500">Belum ada data ekstrakurikuler.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Tanda Tangan & Pengesahan -->
        <div class="grid grid-cols-2 gap-8 text-xs text-gray-800 pt-6 border-t border-gray-200 mt-8">
            <div>
                <p>Mengetahui,</p>
                <p class="font-bold">Kepala Sekolah / Pembina Kesiswaan</p>
                <div class="h-20"></div>
                <p class="font-bold underline">Drs. H. Mulyadi, M.Pd.</p>
                <p class="text-gray-500">NIP. 19740512 199903 1 002</p>
            </div>
            <div class="text-right">
                <p>Jakarta, <?= date('d F Y') ?></p>
                <p class="font-bold">Penyusun / Koordinator Ekskul</p>
                <div class="h-20"></div>
                <p class="font-bold underline">Aulia Amanda Putri</p>
                <p class="text-gray-500">NIM. 202143501234</p>
            </div>
        </div>

        <!-- Footer Cetak -->
        <div class="border-t border-gray-200 pt-4 mt-8 text-center text-[10px] text-gray-400">
            <p>Dokumen ini dicetak secara otomatis dari Sistem Manajemen Minat & Bakat Siswa.</p>
        </div>
    </div>

    <!-- Script Export Excel -->
    <script>
        function exportTableToExcel(tableID, filename = ''){
            let downloadLink;
            const dataType = 'application/vnd.ms-excel';
            const tableSelect = document.getElementById(tableID);
            const tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
            
            filename = filename ? filename + '.xls' : 'laporan_data_ekskul.xls';
            downloadLink = document.createElement("a");
            document.body.appendChild(downloadLink);
            
            if(navigator.msSaveOrOpenBlob){
                const blob = new Blob(['\ufeff', tableSelect.outerHTML], {
                    type: dataType
                });
                navigator.msSaveOrOpenBlob(blob, filename);
            } else {
                downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
                downloadLink.download = filename;
                downloadLink.click();
            }
            document.body.removeChild(downloadLink);
        }
    </script>
</body>
</html>
