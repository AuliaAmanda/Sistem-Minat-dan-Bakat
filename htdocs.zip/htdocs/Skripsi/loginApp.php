<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Ekstrakurikuler Minat & Bakat</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .login-container {
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        
        .login-container:hover {
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        
        .btn-login {
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(118, 75, 162, 0.3);
        }
        
        .input-field:focus {
            border-color: #764ba2;
            box-shadow: 0 0 0 3px rgba(118, 75, 162, 0.2);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center">
    <div class="login-container bg-white rounded-xl overflow-hidden w-full max-w-4xl mx-4 my-8 md:my-0">
        <div class="flex flex-col md:flex-row">
            <!-- Left Side - Illustration -->
            <div class="w-full md:w-1/2 bg-gradient-to-b from-indigo-500 to-purple-600 p-8 flex flex-col items-center justify-center">
                <img src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/1c3e10dd-c98b-406a-b19d-4678b9ceb9cf.png" alt="Diverse group of students engaged in different extracurricular activities like music, sports, painting and coding in a vibrant school setting" class="mb-6 rounded-lg shadow-lg" />
                
                <h2 class="text-2xl font-bold text-white text-center mb-4">Temukan Bakatmu!</h2>
                <p class="text-white text-center opacity-90 mb-6">
                    Portal Ekstrakurikuler membantu kamu mengeksplorasi minat dan mengembangkan bakat melalui berbagai kegiatan yang tersedia.
                </p>
                
                <div class="flex space-x-2">
                    <span class="w-3 h-3 rounded-full bg-white bg-opacity-60"></span>
                    <span class="w-3 h-3 rounded-full bg-white"></span>
                    <span class="w-3 h-3 rounded-full bg-white bg-opacity-60"></span>
                </div>
            </div>
            
            <!-- Right Side - Login Form -->
            <div class="w-full md:w-1/2 p-8">
                <div class="text-center mb-8">
                    <img src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/7656f475-bbe3-4390-a610-15de36a7ee8a.png" alt="Logo Ekstrakurikuler Minat & Bakat berupa buku terbuka dengan ikon berbagai aktivitas melingkari" class="h-10 mx-auto mb-4" />
                    <h1 class="text-2xl font-bold text-gray-800">Masuk ke Akun Anda</h1>
                    <p class="text-gray-600 mt-2">Kelola kegiatan ekstrakurikuler dan temukan bakatmu</p>
                </div>
                
                <form id="loginForm" class="space-y-6">
                    <div>
                        <label for="username" class="block text-sm font-medium text-gray-700 mb-1">NIS/Nama Pengguna</label>
                        <input type="text" id="username" name="username" class="input-field w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-500" placeholder="Masukkan NIS atau nama pengguna" required>
                    </div>
                    
                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Kata Sandi</label>
                        <input type="password" id="password" name="password" class="input-field w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-500" placeholder="Masukkan kata sandi" required>
                    </div>
                    
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <input id="remember-me" name="remember-me" type="checkbox" class="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded">
                            <label for="remember-me" class="ml-2 block text-sm text-gray-700">Ingat saya</label>
                        </div>
                        
                        <div class="text-sm">
                            <a href="#" class="font-medium text-purple-600 hover:text-purple-500">Lupa kata sandi?</a>
                        </div>
                    </div>
                    
                    <div>
                        <button type="submit" class="btn-login w-full py-3 px-4 rounded-lg text-white font-semibold shadow-md">
                            Masuk
                        </button>
                    </div>
                </form>
                
                <div class="mt-6 text-center">
                    <p class="text-sm text-gray-600">
                        Belum punya akun? 
                        <a href="#" class="font-medium text-purple-600 hover:text-purple-500">Daftar sekarang</a>
                    </p>
                </div>
                
                <div class="mt-8 pt-6 border-t border-gray-200 text-center">
                    <p class="text-xs text-gray-500">
                        © 2023 Program Ekstrakurikuler Minat & Bakat. All rights reserved.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const hasil = "1";

            const rawData = JSON.stringify({
                user: document.getElementById('username').value,
                pwd: document.getElementById('password').value
            }); // Example raw JSON data

            console.log(rawData);

            fetch('login.php', {
            method: 'POST', // Specify the HTTP method as POST
            headers: {
                'Content-Type': 'application/json' // Set the Content-Type header
            },
            body: rawData // The raw data to be sent as the request body
            })
            .then(response => {
                if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json(); // Or response.text() if expecting raw text
            })
            .then(data => {
                console.log('Success:', data);
                let hasil = data ;
                if(hasil == "1") {
                alert('Login berhasil! Selamat datang kembali.');
                // Redirect ke dashboard setelah login sukses
                 window.location.href = 'dashboard.php';
                } else {
                    alert('Silakan isi username dan password dengan benar.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
            // Simpan login sederhana (dalam praktiknya gunakan autentikasi yang aman)
            
        });
    </script>
</body>
</html>