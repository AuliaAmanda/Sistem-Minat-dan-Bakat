<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "skripsi";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Koneksi database gagal: " . $conn->connect_error]);
    exit;
}

$nama = trim($_POST['nama_siswa'] ?? '');
$jkel = trim($_POST['jenis_kelamin'] ?? '');
$var1 = intval($_POST['nilai_paskibra'] ?? 0);
$var2 = intval($_POST['nilai_basket'] ?? 0);
$var3 = intval($_POST['nilai_karate'] ?? 0);
$var4 = intval($_POST['nilai_paduan_suara'] ?? 0);
$var5 = intval($_POST['nilai_pramuka'] ?? 0);

if ($nama === '' || $jkel === '') {
    echo json_encode(["status" => "error", "message" => "Nama dan jenis kelamin wajib diisi"]);
    $conn->close();
    exit;
}

// Centroid acuan untuk menentukan kluster awal bagi siswa baru
$centroids = [
    1 => [12, 10, 12, 15, 7],
    2 => [10, 4, 7, 12, 14],
    3 => [12, 8, 9, 6, 4],
    4 => [4, 14, 11, 6, 4],
    5 => [6, 8, 10, 6, 7]
];

$minDist = INF;
$assignedCluster = 1;
foreach ($centroids as $cIndex => $cVal) {
    $dist = sqrt(
        pow($var1 - $cVal[0], 2) +
        pow($var2 - $cVal[1], 2) +
        pow($var3 - $cVal[2], 2) +
        pow($var4 - $cVal[3], 2) +
        pow($var5 - $cVal[4], 2)
    );
    if ($dist < $minDist) {
        $minDist = $dist;
        $assignedCluster = $cIndex;
    }
}

$stmt = $conn->prepare("INSERT INTO tbl_siswa (nama, jkel, var1, var2, var3, var4, var5, cluster) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssiiiiii", $nama, $jkel, $var1, $var2, $var3, $var4, $var5, $assignedCluster);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success", 
        "message" => "Data siswa berhasil disimpan",
        "id" => $stmt->insert_id,
        "cluster" => $assignedCluster
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal menyimpan: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>