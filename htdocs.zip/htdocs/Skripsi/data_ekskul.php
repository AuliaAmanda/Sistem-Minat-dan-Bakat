<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "skripsi";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT id, kode_ekskul, nama_ekskul, jml_anggota, nama_pelatih, keterangan FROM tbl_ekskul ORDER BY id ASC";
$result = $conn->query($sql);
$dataPoints = [];
$totalAnggota = 0;

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $dataPoints[] = $row;
        $totalAnggota += intval($row['jml_anggota']);
    }
}
$totalEkskul = count($dataPoints);
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Ekstrakurikuler - Sistem Manajemen Ekskul</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .form-input:focus { box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.4); }
        .card-stat { transition: transform 0.2s ease, box-shadow 0.2s ease; }
        .card-stat:hover { transform: translateY(-2px); box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); }
    </style>
</head>
<body class="bg-gray-50 text-gray-800">
    <div class="min-h-screen container mx-auto px-4 py-8">
        
        <!-- Header -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
            <div class="bg-gradient-to-r from-emerald-600 to-teal-700 px-6 py-5">
                <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center text-white text-2xl">
                            <i class="fas fa-futbol"></i>
                        </div>
                        <div>
                            <h1 class="text-2xl font-bold text-white">Data Ekstrakurikuler</h1>
                            <p class="text-emerald-100 text-sm">Kelola informasi program kegiatan ekstrakurikuler sekolah</p>
                        </div>
                    </div>
                    <nav class="flex space-x-2">
                        <a href="laporan_ekskul.php" class="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-sm transition flex items-center">
                            <i class="fas fa-file-alt mr-2"></i> Laporan
                        </a>
                        <a href="dashboard.php" class="px-4 py-2 rounded-lg bg-white text-emerald-700 hover:bg-emerald-50 font-semibold text-sm transition shadow flex items-center">
                            <i class="fas fa-home mr-2"></i> Beranda
                        </a>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Info Widget -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div class="card-stat bg-white rounded-xl p-5 border-l-4 border-emerald-500 shadow-sm flex items-center justify-between">
                <div>
                    <p class="text-xs text-gray-500 font-semibold uppercase tracking-wider">Total Ekstrakurikuler</p>
                    <p class="text-2xl font-bold text-gray-800 mt-1"><?= $totalEkskul ?> Kegiatan</p>
                </div>
                <div class="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl">
                    <i class="fas fa-medal"></i>
                </div>
            </div>
            <div class="card-stat bg-white rounded-xl p-5 border-l-4 border-teal-500 shadow-sm flex items-center justify-between">
                <div>
                    <p class="text-xs text-gray-500 font-semibold uppercase tracking-wider">Total Anggota Terdaftar</p>
                    <p class="text-2xl font-bold text-gray-800 mt-1"><?= $totalAnggota ?> Siswa</p>
                </div>
                <div class="w-12 h-12 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center text-xl">
                    <i class="fas fa-users"></i>
                </div>
            </div>
        </div>

        <!-- Form Input -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden mb-8 border border-gray-200">
            <div class="bg-gray-100 px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h2 id="formTitle" class="text-lg font-bold text-gray-800 flex items-center">
                    <i class="fas fa-plus-circle text-emerald-600 mr-2"></i> Tambah Ekstrakurikuler Baru
                </h2>
                <button type="button" id="cancelEditBtn" class="hidden text-xs bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded-md font-medium">
                    Batal Edit
                </button>
            </div>
            
            <div class="p-6">
                <form id="ekskulForm" class="space-y-4">
                    <input type="hidden" id="id_ekskul" name="id_ekskul">
                        
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="kode_ekskul" class="block text-xs font-semibold text-gray-700 mb-1 uppercase tracking-wider">Kode Ekstrakurikuler</label>
                            <input type="text" id="kode_ekskul" name="kode_ekskul" required
                                class="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-emerald-500 focus:ring-emerald-500 text-sm form-input"
                                placeholder="Contoh: EKS001">
                        </div>

                        <div>
                            <label for="nama_ekskul" class="block text-xs font-semibold text-gray-700 mb-1 uppercase tracking-wider">Nama Ekstrakurikuler</label>
                            <input type="text" id="nama_ekskul" name="nama_ekskul" required
                                class="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-emerald-500 focus:ring-emerald-500 text-sm form-input"
                                placeholder="Contoh: PASKIBRA, BASKET">
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="jml_anggota" class="block text-xs font-semibold text-gray-700 mb-1 uppercase tracking-wider">Perkiraan Jumlah Anggota</label>
                            <input type="number" id="jml_anggota" name="jml_anggota" min="0"
                                class="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-emerald-500 focus:ring-emerald-500 text-sm form-input"
                                placeholder="Contoh: 25">
                        </div>

                        <div>
                            <label for="nama_pelatih" class="block text-xs font-semibold text-gray-700 mb-1 uppercase tracking-wider">Nama Pelatih / Pembina</label>
                            <input type="text" id="nama_pelatih" name="nama_pelatih"
                                class="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-emerald-500 focus:ring-emerald-500 text-sm form-input"
                                placeholder="Contoh: Ahmad Fauzi, S.Pd.">
                        </div>
                    </div>

                    <div>
                        <label for="keterangan" class="block text-xs font-semibold text-gray-700 mb-1 uppercase tracking-wider">Keterangan / Deskripsi Program</label>
                        <textarea id="keterangan" name="keterangan" rows="3"
                            class="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-emerald-500 focus:ring-emerald-500 text-sm form-input"
                            placeholder="Deskripsi kegiatan, jadwal latihan, persyaratan khusus, target prestasi..."></textarea>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-3 border-t border-gray-100">
                        <button type="reset" class="px-5 py-2 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-700 font-medium text-sm transition shadow-sm">
                            <i class="fas fa-undo mr-1.5"></i> Reset Form
                        </button>
                        <button type="submit" id="submitBtn" class="px-6 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-sm transition shadow flex items-center">
                            <i class="fas fa-save mr-1.5"></i> Simpan Data
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Tabel Data -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
            <div class="p-6 border-b border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4">
                <div>
                    <h2 class="text-lg font-bold text-gray-800">Daftar Ekstrakurikuler</h2>
                    <p class="text-sm text-gray-500">Daftar seluruh ekstrakurikuler beserta jumlah anggota dan keterangan</p>
                </div>
                <div class="relative w-full md:w-64">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                        <i class="fas fa-search"></i>
                    </span>
                    <input type="text" id="searchInput" placeholder="Cari nama atau kode..." class="w-full pl-9 pr-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table id="ekskulTable" class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">No</th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Kode</th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Nama Ekstrakurikuler</th>
                            <th class="px-5 py-3.5 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Jumlah Anggota</th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Pelatih / Pembina</th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Keterangan</th>
                            <th class="px-5 py-3.5 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200 text-sm">
                        <!-- Data melalui JS -->
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="px-6 py-4 bg-gray-50 border-t border-gray-200">
                <div class="flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div class="text-sm text-gray-600">
                        Menampilkan <span id="ekskulStartItem" class="font-semibold text-gray-800">0</span> sampai <span id="ekskulEndItem" class="font-semibold text-gray-800">0</span> dari <span id="ekskulTotalItems" class="font-semibold text-gray-800">0</span> data
                    </div>
                    <div class="flex space-x-2">
                        <button id="ekskulPrevPage" class="px-3.5 py-1.5 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-700 font-medium text-sm transition disabled:opacity-40 disabled:cursor-not-allowed shadow-sm">
                            <i class="fas fa-chevron-left mr-1"></i> Sebelumnya
                        </button>
                        <button id="ekskulNextPage" class="px-3.5 py-1.5 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-700 font-medium text-sm transition disabled:opacity-40 disabled:cursor-not-allowed shadow-sm">
                            Selanjutnya <i class="fas fa-chevron-right ml-1"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const rawEkskul = <?php echo json_encode($dataPoints); ?>;
        let filteredEkskul = [...rawEkskul];
        let currentEkskulPage = 1;
        const ekskulPerPage = 8;
        
        const ekskulForm = document.getElementById('ekskulForm');
        const formTitle = document.getElementById('formTitle');
        const cancelEditBtn = document.getElementById('cancelEditBtn');
        const submitBtn = document.getElementById('submitBtn');
        const searchInput = document.getElementById('searchInput');

        const ekskulTable = document.getElementById('ekskulTable').getElementsByTagName('tbody')[0];
        const ekskulPrevBtn = document.getElementById('ekskulPrevPage');
        const ekskulNextBtn = document.getElementById('ekskulNextPage');
        const ekskulStartSpan = document.getElementById('ekskulStartItem');
        const ekskulEndSpan = document.getElementById('ekskulEndItem');
        const ekskulTotalSpan = document.getElementById('ekskulTotalItems');
        
        ekskulForm.addEventListener('submit', handleEkskulSubmit);
        ekskulPrevBtn.addEventListener('click', goToPrevEkskulPage);
        ekskulNextBtn.addEventListener('click', goToNextEkskulPage);
        searchInput.addEventListener('input', applySearch);

        cancelEditBtn.addEventListener('click', function() {
            ekskulForm.reset();
            document.getElementById('id_ekskul').value = '';
            formTitle.innerHTML = '<i class="fas fa-plus-circle text-emerald-600 mr-2"></i> Tambah Ekstrakurikuler Baru';
            submitBtn.innerHTML = '<i class="fas fa-save mr-1.5"></i> Simpan Data';
            cancelEditBtn.classList.add('hidden');
        });

        function applySearch() {
            const query = searchInput.value.toLowerCase().trim();
            filteredEkskul = rawEkskul.filter(item => {
                return (item.nama_ekskul && item.nama_ekskul.toLowerCase().includes(query)) ||
                       (item.kode_ekskul && item.kode_ekskul.toLowerCase().includes(query)) ||
                       (item.nama_pelatih && item.nama_pelatih.toLowerCase().includes(query)) ||
                       (item.keterangan && item.keterangan.toLowerCase().includes(query));
            });
            currentEkskulPage = 1;
            renderEkskulTable();
        }

        function handleEkskulSubmit(event) {
            event.preventDefault();
            const formData = new FormData(ekskulForm);
            const isEdit = formData.get('id_ekskul') !== '';
            const targetUrl = isEdit ? 'update_data1.php' : 'insert_data2.php';

            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1.5"></i> Menyimpan...';

            fetch(targetUrl, {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    alert(data.message);
                    window.location.reload();
                } else {
                    alert('Gagal: ' + data.message);
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = isEdit ? '<i class="fas fa-save mr-1.5"></i> Perbarui Data' : '<i class="fas fa-save mr-1.5"></i> Simpan Data';
                }
            })
            .catch(err => {
                console.error(err);
                alert('Terjadi kesalahan koneksi.');
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-save mr-1.5"></i> Simpan Data';
            });
        }
        
        function editEkskul(item) {
            document.getElementById('id_ekskul').value = item.id;
            document.getElementById('kode_ekskul').value = item.kode_ekskul;
            document.getElementById('nama_ekskul').value = item.nama_ekskul;
            document.getElementById('jml_anggota').value = item.jml_anggota;
            document.getElementById('nama_pelatih').value = item.nama_pelatih;
            document.getElementById('keterangan').value = item.keterangan || '';

            formTitle.innerHTML = '<i class="fas fa-edit text-amber-500 mr-2"></i> Edit Ekstrakurikuler: ' + item.nama_ekskul;
            submitBtn.innerHTML = '<i class="fas fa-save mr-1.5"></i> Perbarui Data';
            cancelEditBtn.classList.remove('hidden');

            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        function renderEkskulTable() {
            ekskulTable.innerHTML = '';
            const totalItems = filteredEkskul.length;
            const totalPages = Math.ceil(totalItems / ekskulPerPage) || 1;
            const startIndex = (currentEkskulPage - 1) * ekskulPerPage;
            const endIndex = Math.min(startIndex + ekskulPerPage, totalItems);
            
            ekskulStartSpan.textContent = totalItems > 0 ? startIndex + 1 : 0;
            ekskulEndSpan.textContent = endIndex;
            ekskulTotalSpan.textContent = totalItems;
            
            ekskulPrevBtn.disabled = currentEkskulPage <= 1;
            ekskulNextBtn.disabled = currentEkskulPage >= totalPages;
            
            const displayed = filteredEkskul.slice(startIndex, endIndex);

            if (displayed.length === 0) {
                const row = ekskulTable.insertRow();
                const cell = row.insertCell(0);
                cell.colSpan = 7;
                cell.className = "px-6 py-8 text-center text-gray-500";
                cell.innerHTML = '<i class="fas fa-info-circle mr-2"></i> Tidak ada data ekstrakurikuler yang cocok.';
                return;
            }
            
            displayed.forEach((item, idx) => {
                const row = ekskulTable.insertRow();
                row.className = "hover:bg-emerald-50/50 transition";
                
                // No
                const cellNo = row.insertCell(0);
                cellNo.className = "px-5 py-4 text-gray-500 font-medium";
                cellNo.textContent = startIndex + idx + 1;

                // Kode
                const cellKode = row.insertCell(1);
                cellKode.className = "px-5 py-4 font-mono font-semibold text-emerald-700";
                cellKode.innerHTML = `<span class="bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200 text-xs">${item.kode_ekskul}</span>`;

                // Nama Ekskul
                const cellNama = row.insertCell(2);
                cellNama.className = "px-5 py-4 font-bold text-gray-900";
                cellNama.textContent = item.nama_ekskul;

                // Jumlah Anggota
                const cellJml = row.insertCell(3);
                cellJml.className = "px-5 py-4 text-center";
                cellJml.innerHTML = `<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-gray-100 text-gray-800"><i class="fas fa-user-friends mr-1 text-gray-500"></i> ${item.jml_anggota || 0}</span>`;

                // Pelatih
                const cellPelatih = row.insertCell(4);
                cellPelatih.className = "px-5 py-4 text-gray-700";
                cellPelatih.textContent = item.nama_pelatih || '-';

                // Kolom Keterangan
                const cellKet = row.insertCell(5);
                cellKet.className = "px-5 py-4 text-xs text-gray-600 max-w-xs break-words";
                cellKet.textContent = item.keterangan || '-';

                // Aksi
                const cellAksi = row.insertCell(6);
                cellAksi.className = "px-5 py-4 text-center";
                
                const editBtn = document.createElement('button');
                editBtn.className = "text-emerald-600 hover:text-emerald-900 bg-emerald-50 hover:bg-emerald-100 px-3 py-1 rounded text-xs font-medium transition";
                editBtn.innerHTML = '<i class="fas fa-edit mr-1"></i> Edit';
                editBtn.onclick = () => editEkskul(item);
                cellAksi.appendChild(editBtn);
            });
        }
        
        function goToPrevEkskulPage() {
            if (currentEkskulPage > 1) {
                currentEkskulPage--;
                renderEkskulTable();
            }
        }
        
        function goToNextEkskulPage() {
            const totalPages = Math.ceil(filteredEkskul.length / ekskulPerPage);
            if (currentEkskulPage < totalPages) {
                currentEkskulPage++;
                renderEkskulTable();
            }
        }

        renderEkskulTable();
    </script>
</body>
</html>