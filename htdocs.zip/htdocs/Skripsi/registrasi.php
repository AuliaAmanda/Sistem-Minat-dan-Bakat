<?php
require_once 'koneksi.php';

// Ambil semua ekskul aktif
$sqlEkskul = "SELECT id, kode_ekskul, nama_ekskul FROM tbl_ekskul ORDER BY id ASC";
$resEkskul = $conn->query($sqlEkskul);
$listEkskul = [];
if ($resEkskul) {
    while($r = $resEkskul->fetch_assoc()) {
        $listEkskul[] = $r;
    }
}

// 20 Pertanyaan resmi dari Google Form (Kuisioner Minat & Bakat Siswa SMPN 5 Depok)
$pertanyaan = [
    // Bagian A: Pertanyaan Umum
    1 => ["q" => "Saya lebih suka kegiatan seni seperti bernyanyi dan menggambar daripada kegiatan olahraga.", "kategori" => "A. Pertanyaan Umum Minat & Preferensi"],
    2 => ["q" => "Saya menikmati kegiatan fisik seperti berlari, melompat, atau latihan fisik berat.", "kategori" => "A. Pertanyaan Umum Minat & Preferensi"],
    3 => ["q" => "Saya lebih suka tampil di atas panggung daripada mengikuti lomba olahraga.", "kategori" => "A. Pertanyaan Umum Minat & Preferensi"],
    4 => ["q" => "Saya senang berpartisipasi dalam kegiatan kelompok yang menantang secara fisik.", "kategori" => "A. Pertanyaan Umum Minat & Preferensi"],
    5 => ["q" => "Saya lebih suka kegiatan teratur dan disiplin daripada kegiatan yang fleksibel dan santai.", "kategori" => "A. Pertanyaan Umum Minat & Preferensi"],
    // Bagian B: Pertanyaan Khusus
    6 => ["q" => "Saya tertarik mengikuti kegiatan baris-berbaris dengan formasi yang rapi dan teratur.", "kategori" => "B. Minat Kedisiplinan & Baris-Berbaris (Paskibra)"],
    7 => ["q" => "Saya merasa bangga saat mengikuti upacara bendera dan kegiatan kebangsaan.", "kategori" => "B. Minat Kedisiplinan & Baris-Berbaris (Paskibra)"],
    8 => ["q" => "Saya senang dengan kegiatan yang melatih kedisiplinan dan kekompakan.", "kategori" => "B. Minat Kedisiplinan & Baris-Berbaris (Paskibra)"],
    9 => ["q" => "Saya suka bermain bola basket atau olahraga tim lainnya.", "kategori" => "B. Minat Olahraga & Kerjasama Tim (Basket)"],
    10 => ["q" => "Saya merasa tertantang dalam kompetisi olahraga yang mengandalkan strategi dan kecepatan.", "kategori" => "B. Minat Olahraga & Kerjasama Tim (Basket)"],
    11 => ["q" => "Saya menikmati permainan bola yang melibatkan koordinasi tim dan gerak cepat.", "kategori" => "B. Minat Olahraga & Kerjasama Tim (Basket)"],
    12 => ["q" => "Saya tertarik dengan latihan bela diri seperti karate, taekwondo, atau pencak silat.", "kategori" => "B. Minat Seni Bela Diri (Karate/Silat)"],
    13 => ["q" => "Saya ingin memiliki kemampuan untuk melindungi diri secara fisik.", "kategori" => "B. Minat Seni Bela Diri (Karate/Silat)"],
    14 => ["q" => "Saya senang dengan latihan fisik yang teratur dan fokus pada pengendalian diri.", "kategori" => "B. Minat Seni Bela Diri (Karate/Silat)"],
    15 => ["q" => "Saya senang bernyanyi secara individu maupun bersama dalam kelompok.", "kategori" => "B. Minat Seni Suara & Musikalitas (Paduan Suara)"],
    16 => ["q" => "Saya nyaman tampil di depan orang banyak, misalnya dalam acara sekolah.", "kategori" => "B. Minat Seni Suara & Musikalitas (Paduan Suara)"],
    17 => ["q" => "Saya tertarik mengikuti lomba atau pertunjukan yang melibatkan musik dan suara.", "kategori" => "B. Minat Seni Suara & Musikalitas (Paduan Suara)"],
    18 => ["q" => "Saya menyukai kegiatan di alam terbuka seperti berkemah, mendaki, atau jelajah alam.", "kategori" => "B. Minat Kepanduan & Alam Terbuka (Pramuka/PMR)"],
    19 => ["q" => "Saya ingin belajar keterampilan bertahan hidup dan kedisiplinan lapangan.", "kategori" => "B. Minat Kepanduan & Alam Terbuka (Pramuka/PMR)"],
    20 => ["q" => "Saya senang belajar hal-hal praktis seperti tali-temali, sandi, dan pertolongan pertama.", "kategori" => "B. Minat Kepanduan & Alam Terbuka (Pramuka/PMR)"]
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kuisioner Registrasi Minat & Bakat Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .form-radio:checked { background-color: #4f46e5; border-color: #4f46e5; }
        .scale-card:hover { transform: translateY(-2px); }
    </style>
</head>
<body class="bg-gray-100 text-gray-800">
    <div class="min-h-screen container mx-auto px-4 py-8 max-w-4xl">
        
        <!-- Header Banner Google Form Style -->
        <div class="bg-indigo-700 rounded-t-2xl p-6 text-white shadow-md">
            <div class="flex items-center justify-between">
                <div>
                    <span class="bg-white/20 text-white text-xs font-semibold px-2.5 py-1 rounded-full uppercase tracking-wider">Kuisioner Resmi</span>
                    <h1 class="text-2xl sm:text-3xl font-extrabold mt-2">KUISIONER MINAT DAN BAKAT SISWA</h1>
                    <p class="text-indigo-100 text-xs sm:text-sm mt-1">Pengelompokan Minat Dan Bakat Siswa Untuk Pencocokan Ekstrakurikuler Menggunakan Metode K-Means</p>
                </div>
                <a href="dashboard.php" class="bg-white/10 hover:bg-white/20 text-white px-3 py-2 rounded-lg text-sm transition hidden sm:flex items-center">
                    <i class="fas fa-home mr-1.5"></i> Beranda
                </a>
            </div>
        </div>

        <!-- Info & Petunjuk -->
        <div class="bg-white p-6 rounded-b-2xl shadow-sm mb-6 border-b border-gray-200">
            <p class="text-xs text-gray-600 leading-relaxed">
                Penelitian ini bertujuan untuk membantu mengidentifikasi minat dan bakat siswa secara objektif melalui analisis K-Means clustering. Seluruh data jawaban akan dihitung secara otomatis untuk memetakan ekstrakurikuler yang paling sesuai.
            </p>
            <div class="mt-4 p-3 bg-indigo-50 border-l-4 border-indigo-600 rounded text-xs text-indigo-900">
                <strong>Petunjuk Pengisian:</strong> Pilihlah skala nilai 1 sampai 5 untuk setiap butir pernyataan:<br>
                <div class="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-2 font-medium text-center">
                    <span class="bg-white px-2 py-1 rounded border border-indigo-200">1: Sangat Tidak Setuju</span>
                    <span class="bg-white px-2 py-1 rounded border border-indigo-200">2: Tidak Setuju</span>
                    <span class="bg-white px-2 py-1 rounded border border-indigo-200">3: Netral / Ragu</span>
                    <span class="bg-white px-2 py-1 rounded border border-indigo-200">4: Setuju</span>
                    <span class="bg-white px-2 py-1 rounded border border-indigo-200">5: Sangat Setuju</span>
                </div>
            </div>
            
            <!-- Sinkronisasi Info Ekskul Aktif -->
            <div class="mt-4 pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-2">
                <span class="text-xs text-gray-500">
                    <i class="fas fa-sync-alt text-emerald-600 mr-1"></i> Tersinkronisasi dengan <strong><?= count($listEkskul) ?></strong> Ekstrakurikuler di sistem.
                </span>
                <a href="data_siswa.php" class="text-xs text-indigo-600 hover:underline font-semibold">
                    <i class="fas fa-table mr-1"></i> Lihat Data Siswa Terdaftar &rarr;
                </a>
            </div>
        </div>

        <!-- Form Registrasi -->
        <form id="formKuisioner" class="space-y-6">
            
            <!-- Identitas Siswa -->
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 space-y-4">
                <h2 class="text-base font-bold text-gray-800 border-b border-gray-100 pb-2 flex items-center">
                    <i class="fas fa-id-card text-indigo-600 mr-2"></i> Identitas Siswa
                </h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="nama" class="block text-xs font-bold text-gray-700 uppercase mb-1">Nama Lengkap <span class="text-red-500">*</span></label>
                        <input type="text" id="nama" name="nama" required
                            class="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm"
                            placeholder="Contoh: Muhammad Rizki">
                    </div>

                    <div>
                        <label for="jkel" class="block text-xs font-bold text-gray-700 uppercase mb-1">Jenis Kelamin <span class="text-red-500">*</span></label>
                        <select id="jkel" name="jkel" required
                            class="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm bg-white">
                            <option value="" disabled selected>Pilih jenis kelamin</option>
                            <option value="L">Laki-laki</option>
                            <option value="P">Perempuan</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Daftar 20 Butir Pertanyaan -->
            <?php 
            $currentKategori = "";
            foreach ($pertanyaan as $no => $item): 
                if ($currentKategori !== $item['kategori']):
                    $currentKategori = $item['kategori'];
            ?>
                <div class="bg-gradient-to-r from-gray-800 to-gray-700 text-white px-5 py-3 rounded-xl font-bold text-sm shadow-sm flex items-center">
                    <i class="fas fa-clipboard-list mr-2 text-indigo-400"></i> <?= $currentKategori ?>
                </div>
            <?php endif; ?>

                <div class="bg-white p-5 rounded-2xl shadow-sm border border-gray-200">
                    <p class="text-sm font-semibold text-gray-900 mb-3">
                        <span class="inline-block w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 text-center text-xs leading-6 font-bold mr-2"><?= $no ?></span>
                        <?= htmlspecialchars($item['q']) ?> <span class="text-red-500">*</span>
                    </p>

                    <!-- Pilihan Skala 1 - 5 -->
                    <div class="grid grid-cols-5 gap-2 text-center">
                        <?php for($val = 1; $val <= 5; $val++): ?>
                            <label class="cursor-pointer">
                                <input type="radio" name="q<?= $no ?>" value="<?= $val ?>" required class="sr-only peer">
                                <div class="py-2.5 px-1 rounded-xl border border-gray-200 peer-checked:bg-indigo-600 peer-checked:text-white peer-checked:border-indigo-600 peer-checked:shadow hover:bg-gray-50 transition text-xs font-bold text-gray-700">
                                    <span class="text-base block mb-0.5"><?= $val ?></span>
                                    <span class="text-[10px] font-normal hidden sm:block">
                                        <?= $val == 1 ? 'STS' : ($val == 2 ? 'TS' : ($val == 3 ? 'N' : ($val == 4 ? 'S' : 'SS'))) ?>
                                    </span>
                                </div>
                            </label>
                        <?php endfor; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <!-- Tombol Kirim -->
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 flex flex-col sm:flex-row justify-between items-center gap-4">
                <a href="data_siswa.php" class="text-sm text-gray-500 hover:text-gray-800">
                    <i class="fas fa-arrow-left mr-1"></i> Batal & Lihat Data Siswa
                </a>
                <div class="flex space-x-3 w-full sm:w-auto">
                    <button type="reset" class="px-5 py-2.5 rounded-xl border border-gray-300 text-gray-700 font-medium text-sm hover:bg-gray-50 transition flex-1 sm:flex-initial">
                        Reset Jawaban
                    </button>
                    <button type="submit" id="submitBtn" class="px-7 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow transition flex items-center justify-center flex-1 sm:flex-initial">
                        <i class="fas fa-paper-plane mr-2"></i> Kirim Kuisioner & Simpan
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- Script Pengiriman Form -->
    <script>
        const form = document.getElementById('formKuisioner');
        const submitBtn = document.getElementById('submitBtn');

        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Menghitung Skor & Menyimpan...';

            fetch('proses_registrasi.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    alert('Sukses! Data siswa dan nilai survei berhasil disimpan.\n' + data.message);
                    window.location.href = 'data_siswa.php';
                } else {
                    alert('Gagal: ' + data.message);
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i class="fas fa-paper-plane mr-2"></i> Kirim Kuisioner & Simpan';
                }
            })
            .catch(err => {
                console.error(err);
                alert('Terjadi kesalahan saat memproses kuisioner.');
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-paper-plane mr-2"></i> Kirim Kuisioner & Simpan';
            });
        });
    </script>
</body>
</html>
