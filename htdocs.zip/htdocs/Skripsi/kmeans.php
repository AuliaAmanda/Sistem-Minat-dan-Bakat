<?php
if (!headers_sent()) {
    header('Content-Type: application/json');
}
require_once 'koneksi.php';

// Ambil seluruh ekskul yang aktif untuk menentukan K secara dinamis
$resEkskul = $conn->query("SELECT id, kode_ekskul, nama_ekskul FROM tbl_ekskul ORDER BY id ASC");
$ekskulList = [];
if ($resEkskul) {
    while($ek = $resEkskul->fetch_assoc()) {
        $ekskulList[] = $ek;
    }
}

$K = count($ekskulList);
if ($K < 2) {
    $K = 5; // Default minimal fallback
}

// Ambil seluruh data siswa
$sql = "SELECT id, nama, var1, var2, var3, var4, var5 FROM tbl_siswa ORDER BY id ASC";
$result = $conn->query($sql);
$dataPoints = [];
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $dataPoints[] = [
            floatval($row["var1"]),
            floatval($row["var2"]),
            floatval($row["var3"]),
            floatval($row["var4"]),
            floatval($row["var5"]),
            $row["nama"],
            intval($row["id"])
        ];
    }
}

if (empty($dataPoints)) {
    echo json_encode(["status" => "error", "message" => "Tidak ada data siswa"]);
    exit;
}

// Centroid awal acuan yang deterministik
$baseCentroids = [
    [12, 10, 12, 15, 7],
    [10, 4, 7, 12, 14],
    [12, 8, 9, 6, 4],
    [4, 14, 11, 6, 4],
    [6, 8, 10, 6, 7]
];

$initialCentroids = [];
for ($i = 0; $i < $K; $i++) {
    if (isset($baseCentroids[$i])) {
        $initialCentroids[$i] = $baseCentroids[$i];
    } else {
        // Jika jumlah ekskul bertambah > 5, generate centroid turunan berbasis variasi siswa
        $idx = $i % count($dataPoints);
        $initialCentroids[$i] = [
            $dataPoints[$idx][0],
            $dataPoints[$idx][1],
            $dataPoints[$idx][2],
            $dataPoints[$idx][3],
            $dataPoints[$idx][4]
        ];
    }
}

// Hapus rekaman iterasi sebelumnya
$conn->query("TRUNCATE TABLE tbl_iterasi_kmeans");

// Algoritma K-Means dengan logging iterasi ke database
$centroids = $initialCentroids;
$maxIterations = 100;
$finalClusters = [];
$actualIter = 0;

function calculateEuclidean($p1, $p2) {
    $sum = 0.0;
    for ($d = 0; $d < 5; $d++) {
        $diff = ($p1[$d] ?? 0) - ($p2[$d] ?? 0);
        $sum += ($diff * $diff);
    }
    return sqrt($sum);
}

for ($iter = 1; $iter <= $maxIterations; $iter++) {
    $actualIter = $iter;
    $clusters = array_fill(0, $K, []);

    // 1. Assignment
    foreach ($dataPoints as $p) {
        $minDist = INF;
        $bestC = 0;
        for ($c = 0; $c < $K; $c++) {
            $dist = calculateEuclidean($p, $centroids[$c]);
            if ($dist < $minDist) {
                $minDist = $dist;
                $bestC = $c;
            }
        }
        $clusters[$bestC][] = $p;
    }

    // Catat log iterasi ke tbl_iterasi_kmeans
    for ($c = 0; $c < $K; $c++) {
        $cNum = $c + 1;
        $namaEkskul = $ekskulList[$c]['nama_ekskul'] ?? "Ekskul $cNum";
        $cJson = json_encode($centroids[$c]);
        $jmlAnggota = count($clusters[$c]);

        $stmtLog = $conn->prepare("INSERT INTO tbl_iterasi_kmeans (iterasi, cluster_num, nama_ekskul, centroid_json, anggota_count) VALUES (?, ?, ?, ?, ?)");
        $stmtLog->bind_param("iissi", $iter, $cNum, $namaEkskul, $cJson, $jmlAnggota);
        $stmtLog->execute();
        $stmtLog->close();
    }

    // 2. Update step
    $newCentroids = [];
    $changed = false;
    for ($c = 0; $c < $K; $c++) {
        $pts = $clusters[$c];
        if (empty($pts)) {
            $newCentroids[$c] = $centroids[$c];
            continue;
        }

        $sums = [0, 0, 0, 0, 0];
        $count = count($pts);
        foreach ($pts as $pt) {
            for ($d = 0; $d < 5; $d++) {
                $sums[$d] += $pt[$d];
            }
        }

        $mean = [];
        for ($d = 0; $d < 5; $d++) {
            $mean[$d] = $sums[$d] / $count;
        }
        $newCentroids[$c] = $mean;

        if (calculateEuclidean($newCentroids[$c], $centroids[$c]) > 0.0001) {
            $changed = true;
        }
    }

    $centroids = $newCentroids;
    $finalClusters = $clusters;

    if (!$changed) {
        break; // Konvergen
    }
}

// Simpan hasil clustering akhir ke tbl_siswa
$updatedRows = 0;
foreach ($finalClusters as $cIndex => $pts) {
    $cNum = $cIndex + 1;
    foreach ($pts as $p) {
        $sid = $p[6];
        if ($conn->query("UPDATE tbl_siswa SET cluster = $cNum WHERE id = $sid")) {
            $updatedRows++;
        }
    }
}

if (!defined('KMEANS_NO_ECHO')) {
    echo json_encode([
        "status" => "success",
        "message" => "Clustering dinamis berhasil diproses",
        "k" => $K,
        "iterations" => $actualIter,
        "updated_rows" => $updatedRows
    ]);
}
?>