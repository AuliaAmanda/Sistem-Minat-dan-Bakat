<?php
require_once 'koneksi.php';

$totalSiswa = 0;
$totalEkskul = 0;
$totalRespon = 0;

$resSiswa = $conn->query("SELECT COUNT(*) AS total FROM tbl_siswa");
if ($resSiswa) $totalSiswa = $resSiswa->fetch_assoc()['total'];

$resEkskul = $conn->query("SELECT COUNT(*) AS total FROM tbl_ekskul");
if ($resEkskul) $totalEkskul = $resEkskul->fetch_assoc()['total'];

$resRespon = $conn->query("SELECT COUNT(*) AS total FROM tbl_respon_kuisioner");
if ($resRespon) $totalRespon = $resRespon->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Manajemen Minat & Bakat Ekstrakurikuler</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .card-menu {
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .card-menu:hover {
            transform: translateY(-6px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
    </style>
</head>
<body class="bg-gray-50 text-gray-800 flex flex-col min-h-screen">
    
    <!-- Header -->
    <header class="bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-800 text-white shadow-xl">
        <div class="container mx-auto px-6 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
            <div class="flex items-center space-x-4">
                <div class="w-14 h-14 bg-white/10 backdrop-blur rounded-2xl flex items-center justify-center text-white text-3xl border border-white/20 shadow-inner">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <div>
                    <h1 class="text-2xl font-black tracking-tight">SISTEM MINAT & BAKAT</h1>
                    <p class="text-xs text-blue-100 font-medium tracking-wide uppercase">Rekomendasi Penempatan Ekstrakurikuler Menggunakan Algoritma K-Means</p>
                </div>
            </div>
            <nav class="flex items-center space-x-2">
                <a href="registrasi.php" class="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs uppercase tracking-wider shadow transition flex items-center">
                    <i class="fas fa-edit mr-1.5"></i> Isi Kuisioner
                </a>
                <span class="inline-flex items-center px-3 py-2 rounded-xl text-xs font-semibold bg-white/10 text-white border border-white/20">
                    <span class="w-2 h-2 rounded-full bg-emerald-400 mr-2 animate-pulse"></span> Sistem Aktif
                </span>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto px-6 py-10 flex-1">
        
        <!-- Welcome Hero -->
        <section class="mb-10 bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-100 rounded-2xl p-8 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
            <div class="max-w-2xl">
                <span class="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-indigo-100 text-indigo-700 mb-3 inline-block">Dashboard Utama</span>
                <h2 class="text-3xl font-extrabold text-gray-900 tracking-tight">Selamat Datang di Sistem Minat & Bakat</h2>
                <p class="text-gray-600 text-sm mt-2 leading-relaxed">
                    Sistem rekomendasi penempatan kegiatan ekstrakurikuler sekolah terintegrasi berbasis penilaian kuisioner minat bakat dan algoritma <strong>K-Means Clustering Dinamis</strong>.
                </p>
            </div>
            <div class="grid grid-cols-3 gap-3 w-full md:w-auto">
                <div class="bg-white p-4 rounded-xl border border-indigo-100 shadow-sm text-center">
                    <p class="text-[10px] font-semibold text-gray-500 uppercase">Siswa Terdaftar</p>
                    <p class="text-xl font-black text-indigo-600 mt-1"><?= $totalSiswa ?></p>
                </div>
                <div class="bg-white p-4 rounded-xl border border-emerald-100 shadow-sm text-center">
                    <p class="text-[10px] font-semibold text-gray-500 uppercase">Total Ekskul</p>
                    <p class="text-xl font-black text-emerald-600 mt-1"><?= $totalEkskul ?></p>
                </div>
                <div class="bg-white p-4 rounded-xl border border-purple-100 shadow-sm text-center">
                    <p class="text-[10px] font-semibold text-gray-500 uppercase">Respon Form</p>
                    <p class="text-xl font-black text-purple-600 mt-1"><?= $totalRespon ?></p>
                </div>
            </div>
        </section>

        <!-- Menu Navigation Cards (4 Modul Utama) -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            
            <!-- Card 1: Form Registrasi Kuisioner -->
            <a href="registrasi.php" class="card-menu bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm flex flex-col justify-between group">
                <div class="p-6">
                    <div class="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-2xl mb-4 group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition duration-300">
                        <i class="fas fa-clipboard-check"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-1">Form Kuisioner</h3>
                    <p class="text-gray-500 text-xs leading-relaxed">
                        Form survei minat bakat 20 butir soal (Google Form) dengan penilaian otomatis masuk database.
                    </p>
                </div>
                <div class="bg-gray-50 px-6 py-3 border-t border-gray-100 flex items-center justify-between text-indigo-600 font-semibold text-xs group-hover:bg-indigo-600 group-hover:text-white transition">
                    <span>Buka Kuisioner</span>
                    <i class="fas fa-arrow-right"></i>
                </div>
            </a>

            <!-- Card 2: Data Siswa (Terpisah) -->
            <a href="data_siswa.php" class="card-menu bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm flex flex-col justify-between group">
                <div class="p-6">
                    <div class="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-2xl mb-4 group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition duration-300">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-1">Data Siswa</h3>
                    <p class="text-gray-500 text-xs leading-relaxed">
                        Tabel daftar data siswa dan rekap skor minat yang tersinkronisasi otomatis dengan total ekskul.
                    </p>
                </div>
                <div class="bg-gray-50 px-6 py-3 border-t border-gray-100 flex items-center justify-between text-blue-600 font-semibold text-xs group-hover:bg-blue-600 group-hover:text-white transition">
                    <span>Lihat Data Siswa</span>
                    <i class="fas fa-arrow-right"></i>
                </div>
            </a>

            <!-- Card 3: Data Ekskul -->
            <a href="data_ekskul.php" class="card-menu bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm flex flex-col justify-between group">
                <div class="p-6">
                    <div class="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-2xl mb-4 group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white transition duration-300">
                        <i class="fas fa-futbol"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-1">Data Ekstrakurikuler</h3>
                    <p class="text-gray-500 text-xs leading-relaxed">
                        Kelola program ekskul sekolah. Tambah/kurang ekskul akan langsung sinkron ke seluruh sistem.
                    </p>
                </div>
                <div class="bg-gray-50 px-6 py-3 border-t border-gray-100 flex items-center justify-between text-emerald-600 font-semibold text-xs group-hover:bg-emerald-600 group-hover:text-white transition">
                    <span>Kelola Ekskul</span>
                    <i class="fas fa-arrow-right"></i>
                </div>
            </a>

            <!-- Card 4: Clustering & Iterasi -->
            <a href="cluster_siswa.php" class="card-menu bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm flex flex-col justify-between group">
                <div class="p-6">
                    <div class="w-14 h-14 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center text-2xl mb-4 group-hover:scale-110 group-hover:bg-purple-600 group-hover:text-white transition duration-300">
                        <i class="fas fa-project-diagram"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-1">Hasil Clustering</h3>
                    <p class="text-gray-500 text-xs leading-relaxed">
                        Analisis pengelompokan K-Means, log iterasi komputasi database, dan rekomendasi ekskul.
                    </p>
                </div>
                <div class="bg-gray-50 px-6 py-3 border-t border-gray-100 flex items-center justify-between text-purple-600 font-semibold text-xs group-hover:bg-purple-600 group-hover:text-white transition">
                    <span>Hasil Clustering</span>
                    <i class="fas fa-arrow-right"></i>
                </div>
            </a>
        </div>

        <!-- Section Cetak Laporan Cepat & Database Iterasi -->
        <div class="bg-white rounded-2xl border border-gray-200 p-8 shadow-sm">
            <h3 class="text-lg font-bold text-gray-900 mb-1 flex items-center">
                <i class="fas fa-print text-gray-600 mr-2"></i> Cetak Dokumen Laporan & Riwayat Iterasi
            </h3>
            <p class="text-sm text-gray-500 mb-6">Pilih modul dokumen akademik atau audit database iterasi K-Means</p>

            <div class="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <a href="laporan_cluster.php" target="_blank" class="flex items-center p-4 rounded-xl border border-gray-200 hover:border-purple-500 hover:bg-purple-50/50 transition">
                    <div class="w-10 h-10 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center text-lg mr-3">
                        <i class="fas fa-file-contract"></i>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-gray-800">Laporan Clustering</p>
                        <p class="text-[10px] text-gray-500">Rekap kluster & PDF</p>
                    </div>
                </a>

                <a href="laporan_siswa.php" target="_blank" class="flex items-center p-4 rounded-xl border border-gray-200 hover:border-blue-500 hover:bg-blue-50/50 transition">
                    <div class="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center text-lg mr-3">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-gray-800">Laporan Data Siswa</p>
                        <p class="text-[10px] text-gray-500">Rekap profil & Excel</p>
                    </div>
                </a>

                <a href="laporan_ekskul.php" target="_blank" class="flex items-center p-4 rounded-xl border border-gray-200 hover:border-emerald-500 hover:bg-emerald-50/50 transition">
                    <div class="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center text-lg mr-3">
                        <i class="fas fa-file-medical-alt"></i>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-gray-800">Laporan Data Ekskul</p>
                        <p class="text-[10px] text-gray-500">Rekap pembina & kuota</p>
                    </div>
                </a>

                <a href="iterasi.php" class="flex items-center p-4 rounded-xl border border-gray-200 hover:border-indigo-500 hover:bg-indigo-50/50 transition">
                    <div class="w-10 h-10 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center text-lg mr-3">
                        <i class="fas fa-database"></i>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-gray-800">Log Database Iterasi</p>
                        <p class="text-[10px] text-gray-500">Rekam jejak centroid</p>
                    </div>
                </a>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-400 py-6 border-t border-gray-800 text-center text-xs">
        <div class="container mx-auto px-6">
            <p>&copy; 2026 Sistem Manajemen Minat & Bakat Siswa. Dikembangkan untuk Tugas Akhir / Skripsi.</p>
        </div>
    </footer>
</body>
</html>
