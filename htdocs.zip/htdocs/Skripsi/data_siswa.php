<?php
require_once 'koneksi.php';

// Ambil daftar ekskul dinamis
$sqlEkskul = "SELECT id, kode_ekskul, nama_ekskul FROM tbl_ekskul ORDER BY id ASC";
$resEkskul = $conn->query($sqlEkskul);
$listEkskul = [];
if ($resEkskul) {
    while ($r = $resEkskul->fetch_assoc()) {
        $listEkskul[] = $r;
    }
}

// Ambil daftar siswa beserta nilai ekskul
$sqlSiswa = "SELECT id, nama, jkel, cluster FROM tbl_siswa ORDER BY id ASC";
$resSiswa = $conn->query($sqlSiswa);
$listSiswa = [];
if ($resSiswa) {
    while ($s = $resSiswa->fetch_assoc()) {
        $sid = $s['id'];
        // Ambil nilai per ekskul dari tabel nilai
        $s['nilai_ekskul'] = [];
        $resNilai = $conn->query("SELECT ekskul_id, nilai FROM tbl_nilai_siswa_ekskul WHERE siswa_id = $sid");
        if ($resNilai) {
            while ($n = $resNilai->fetch_assoc()) {
                $s['nilai_ekskul'][$n['ekskul_id']] = $n['nilai'];
            }
        }
        $listSiswa[] = $s;
    }
}
$totalSiswa = count($listSiswa);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa - Sistem Manajemen Minat Bakat</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-50 text-gray-800">
    <div class="min-h-screen container mx-auto px-4 py-8">
        
        <!-- Header -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
            <div class="bg-gradient-to-r from-blue-600 to-indigo-700 px-6 py-5">
                <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center text-white text-2xl">
                            <i class="fas fa-users"></i>
                        </div>
                        <div>
                            <h1 class="text-2xl font-bold text-white">Daftar Data Siswa</h1>
                            <p class="text-blue-100 text-sm">Rekapitulasi data siswa dan skor minat ekstrakurikuler yang tersinkronisasi</p>
                        </div>
                    </div>
                    <nav class="flex space-x-2">
                        <a href="registrasi.php" class="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-sm transition shadow flex items-center">
                            <i class="fas fa-plus-circle mr-2"></i> Form Registrasi
                        </a>
                        <a href="laporan_siswa.php" class="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-sm transition flex items-center">
                            <i class="fas fa-file-alt mr-2"></i> Laporan
                        </a>
                        <a href="dashboard.php" class="px-4 py-2 rounded-lg bg-white text-indigo-700 hover:bg-indigo-50 font-semibold text-sm transition shadow flex items-center">
                            <i class="fas fa-home mr-2"></i> Beranda
                        </a>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Tabel Data Siswa -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
            <div class="p-6 border-b border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4">
                <div>
                    <h2 class="text-lg font-bold text-gray-800">Daftar Siswa & Penilaian Ekstrakurikuler</h2>
                    <p class="text-sm text-gray-500">Kolom penilaian menyesuaikan secara otomatis dengan total ekskul yang ada (<?= count($listEkskul) ?> Ekskul)</p>
                </div>
                <div class="relative w-full md:w-64">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                        <i class="fas fa-search"></i>
                    </span>
                    <input type="text" id="searchInput" placeholder="Cari nama atau ID..." class="w-full pl-9 pr-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table id="siswaTable" class="min-w-full divide-y divide-gray-200 text-sm">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-4 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase">ID</th>
                            <th class="px-4 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase">Nama Siswa</th>
                            <th class="px-4 py-3.5 text-center text-xs font-semibold text-gray-600 uppercase">Gender</th>
                            <?php foreach($listEkskul as $ek): ?>
                                <th class="px-3 py-3.5 text-center text-xs font-semibold text-gray-700 uppercase bg-blue-50/50" title="<?= htmlspecialchars($ek['nama_ekskul']) ?>">
                                    <?= htmlspecialchars($ek['nama_ekskul']) ?>
                                </th>
                            <?php endforeach; ?>
                            <th class="px-4 py-3.5 text-center text-xs font-semibold text-gray-600 uppercase">Cluster</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if(!empty($listSiswa)): ?>
                            <?php foreach($listSiswa as $s): ?>
                                <tr class="hover:bg-blue-50/30 transition student-row" data-name="<?= strtolower(htmlspecialchars($s['nama'])) ?>" data-id="<?= $s['id'] ?>">
                                    <td class="px-4 py-3 font-medium text-gray-900"><?= $s['id'] ?></td>
                                    <td class="px-4 py-3 font-bold text-gray-900"><?= htmlspecialchars($s['nama']) ?></td>
                                    <td class="px-4 py-3 text-center">
                                        <?= $s['jkel'] === 'L' 
                                            ? '<span class="text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full text-xs font-medium">L</span>' 
                                            : '<span class="text-pink-700 bg-pink-50 px-2 py-0.5 rounded-full text-xs font-medium">P</span>' ?>
                                    </td>
                                    <?php foreach($listEkskul as $ek): 
                                        $val = $s['nilai_ekskul'][$ek['id']] ?? 0;
                                    ?>
                                        <td class="px-3 py-3 text-center font-mono font-semibold text-gray-700">
                                            <?= $val ?>
                                        </td>
                                    <?php endforeach; ?>
                                    <td class="px-4 py-3 text-center">
                                        <span class="bg-purple-100 text-purple-800 font-bold px-2.5 py-0.5 rounded-full text-xs">C<?= $s['cluster'] ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="<?= 4 + count($listEkskul) ?>" class="px-6 py-8 text-center text-gray-500">
                                    Belum ada data siswa. Silakan tambahkan melalui <a href="registrasi.php" class="text-blue-600 underline">Form Registrasi</a>.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="px-6 py-4 bg-gray-50 border-t border-gray-200 text-sm text-gray-600 flex justify-between items-center">
                <span>Total: <strong><?= $totalSiswa ?></strong> Siswa Terdaftar</span>
                <a href="cluster_siswa.php" class="text-indigo-600 hover:text-indigo-800 font-semibold text-xs flex items-center">
                    Lihat Analisis Clustering <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </div>
        </div>
    </div>

    <script>
        const searchInput = document.getElementById('searchInput');
        const rows = document.querySelectorAll('.student-row');

        searchInput.addEventListener('input', function() {
            const q = this.value.toLowerCase().trim();
            rows.forEach(r => {
                const name = r.getAttribute('data-name');
                const id = r.getAttribute('data-id');
                if (name.includes(q) || id.includes(q)) {
                    r.style.display = '';
                } else {
                    r.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
