<?php

            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "skripsi";

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);

            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            echo "Connected successfully (MySQLi Procedural)";

            $sql = "SELECT id,nama,jkel,cluster FROM tbl_siswa"; // Select specific columns

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    $dataPoints[] = $row;
                }
            } else {
                echo "0 results";
            } 

            //print_r($dataPoints);
            echo json_encode($dataPoints);
            mysqli_close($conn);
            
?>
