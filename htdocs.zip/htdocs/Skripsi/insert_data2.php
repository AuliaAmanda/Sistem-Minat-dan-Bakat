<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "skripsi";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Koneksi database gagal: " . $conn->connect_error]);
    exit;
}

$kode_ekskul = trim($_POST['kode_ekskul'] ?? '');
$nama_ekskul = trim($_POST['nama_ekskul'] ?? '');
$jml_anggota = intval($_POST['jml_anggota'] ?? 0);
$nama_pelatih = trim($_POST['nama_pelatih'] ?? '');
$keterangan = trim($_POST['keterangan'] ?? '');

if ($kode_ekskul === '' || $nama_ekskul === '') {
    echo json_encode(["status" => "error", "message" => "Kode dan Nama Ekskul wajib diisi"]);
    $conn->close();
    exit;
}

$stmt = $conn->prepare("INSERT INTO tbl_ekskul (kode_ekskul, nama_ekskul, jml_anggota, nama_pelatih, keterangan) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("ssiss", $kode_ekskul, $nama_ekskul, $jml_anggota, $nama_pelatih, $keterangan);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success", 
        "message" => "Data ekstrakurikuler berhasil ditambahkan",
        "id" => $stmt->insert_id
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal menyimpan: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>