<?php
require_once 'koneksi.php';

// Ambil seluruh data iterasi yang tersimpan
$sql = "SELECT iterasi, cluster_num, nama_ekskul, centroid_json, anggota_count, created_at 
        FROM tbl_iterasi_kmeans 
        ORDER BY id DESC LIMIT 50";
$result = $conn->query($sql);

$iterasiData = [];
$maxIterasi = 0;
if ($result) {
    while($row = $result->fetch_assoc()) {
        $iterasiData[] = $row;
        if (intval($row['iterasi']) > $maxIterasi) {
            $maxIterasi = intval($row['iterasi']);
        }
    }
}

// Total data kuisioner tersimpan
$resCount = $conn->query("SELECT COUNT(*) AS total FROM tbl_respon_kuisioner");
$totalRespon = $resCount ? $resCount->fetch_assoc()['total'] : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Database Iterasi K-Means - Sistem Minat Bakat</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-50 text-gray-800">
    <div class="min-h-screen container mx-auto px-4 py-8">
        
        <!-- Header -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
            <div class="bg-gradient-to-r from-purple-700 to-indigo-800 px-6 py-5">
                <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center text-white text-2xl">
                            <i class="fas fa-database"></i>
                        </div>
                        <div>
                            <h1 class="text-2xl font-bold text-white">Database Iterasi K-Means</h1>
                            <p class="text-purple-100 text-sm">Rekam jejak komputasi iterasi centroid dan hasil pengelompokan kuisioner</p>
                        </div>
                    </div>
                    <nav class="flex space-x-2">
                        <a href="cluster_siswa.php" class="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-sm transition flex items-center">
                            <i class="fas fa-project-diagram mr-2"></i> Hasil Clustering
                        </a>
                        <a href="dashboard.php" class="px-4 py-2 rounded-lg bg-white text-purple-700 hover:bg-purple-50 font-semibold text-sm transition shadow flex items-center">
                            <i class="fas fa-home mr-2"></i> Beranda
                        </a>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Stat Widget -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div class="bg-white rounded-xl p-5 border-l-4 border-purple-500 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-xs text-gray-500 uppercase font-semibold">Total Respon Kuisioner</p>
                    <p class="text-2xl font-bold text-gray-800 mt-1"><?= $totalRespon ?> Responden</p>
                </div>
                <div class="w-12 h-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-xl">
                    <i class="fas fa-poll-h"></i>
                </div>
            </div>
            <div class="bg-white rounded-xl p-5 border-l-4 border-indigo-500 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-xs text-gray-500 uppercase font-semibold">Status Konvergensi Terakhir</p>
                    <p class="text-2xl font-bold text-indigo-600 mt-1"><?= $maxIterasi > 0 ? "Iterasi Ke-$maxIterasi" : "Belum Berjalan" ?></p>
                </div>
                <div class="w-12 h-12 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-xl">
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
            <div class="bg-white rounded-xl p-5 border-l-4 border-emerald-500 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-xs text-gray-500 uppercase font-semibold">Tabel Database</p>
                    <p class="text-sm font-bold text-gray-700 mt-1 font-mono">tbl_iterasi_kmeans</p>
                </div>
                <div class="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl">
                    <i class="fas fa-table"></i>
                </div>
            </div>
        </div>

        <!-- Tabel Log Database Iterasi -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
            <div class="p-6 border-b border-gray-200">
                <h2 class="text-lg font-bold text-gray-800">Riwayat Catatan Centroid & Anggota per Iterasi</h2>
                <p class="text-sm text-gray-500">Menyimpan posisi titik pusat (centroid) pada setiap putaran perhitungan algoritma K-Means</p>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200 text-sm">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-5 py-3.5 text-center text-xs font-semibold text-gray-600 uppercase">Iterasi</th>
                            <th class="px-5 py-3.5 text-center text-xs font-semibold text-gray-600 uppercase">Cluster</th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase">Ekstrakurikuler</th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase">Nilai Centroid (Koordinat)</th>
                            <th class="px-5 py-3.5 text-center text-xs font-semibold text-gray-600 uppercase">Jumlah Siswa</th>
                            <th class="px-5 py-3.5 text-center text-xs font-semibold text-gray-600 uppercase">Waktu Komputasi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if(!empty($iterasiData)): ?>
                            <?php foreach($iterasiData as $row): 
                                $centroidArr = json_decode($row['centroid_json'], true);
                                $centroidStr = is_array($centroidArr) ? implode(' | ', array_map(function($v){ return round($v, 2); }, $centroidArr)) : $row['centroid_json'];
                            ?>
                                <tr class="hover:bg-purple-50/30 transition">
                                    <td class="px-5 py-3 text-center font-bold text-purple-700">Iterasi <?= $row['iterasi'] ?></td>
                                    <td class="px-5 py-3 text-center">
                                        <span class="bg-purple-100 text-purple-800 font-bold px-2 py-0.5 rounded text-xs">C<?= $row['cluster_num'] ?></span>
                                    </td>
                                    <td class="px-5 py-3 font-semibold text-gray-900"><?= htmlspecialchars($row['nama_ekskul']) ?></td>
                                    <td class="px-5 py-3 font-mono text-xs text-gray-600 bg-gray-50/50 rounded">[ <?= $centroidStr ?> ]</td>
                                    <td class="px-5 py-3 text-center font-bold text-gray-800"><?= $row['anggota_count'] ?> Siswa</td>
                                    <td class="px-5 py-3 text-center text-xs text-gray-500"><?= $row['created_at'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="px-6 py-8 text-center text-gray-500">
                                    Belum ada data rekaman iterasi. Klik tombol "Proses Ulang K-Means" di halaman <a href="cluster_siswa.php" class="text-indigo-600 underline">Hasil Clustering</a> untuk menghasilkan log iterasi.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
