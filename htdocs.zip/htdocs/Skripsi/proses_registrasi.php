<?php
header('Content-Type: application/json');
require_once 'koneksi.php';

$nama = trim($_POST['nama'] ?? '');
$jkel = trim($_POST['jkel'] ?? '');

if ($nama === '' || $jkel === '') {
    echo json_encode(["status" => "error", "message" => "Nama dan jenis kelamin wajib diisi"]);
    exit;
}

// Tangkap jawaban Q1 s/d Q20
$q = [];
for ($i = 1; $i <= 20; $i++) {
    $q[$i] = intval($_POST["q$i"] ?? 3);
}

// 1. Hitung skor untuk masing-masing pilar ekstrakurikuler dari jawaban kuisioner
// Paskibra: Baris-berbaris, disiplin upacara, kelompok (Q5, Q6, Q7, Q8)
$scorePaskibra = $q[5] + $q[6] + $q[7] + $q[8];

// Basket: Olahraga fisik cepat, kompetisi, tim bola (Q2, Q9, Q10, Q11)
$scoreBasket = $q[2] + $q[9] + $q[10] + $q[11];

// Karate / Silat: Bela diri, lindungi fisik, fokus kendali diri (Q4, Q12, Q13, Q14)
$scoreKarate = $q[4] + $q[12] + $q[13] + $q[14];

// Paduan Suara: Seni vokal, panggung, pertunjukan musik (Q1, Q3, Q15, Q16, Q17)
$scorePadus = intval(round(($q[1] + $q[3] + $q[15] + $q[16] + $q[17]) * (4 / 5)));

// Pramuka / PMR: Alam bebas, bertahan hidup, tali-temali & P3K (Q18, Q19, Q20)
$scorePramuka = intval(round(($q[18] + $q[19] + $q[20]) * (4 / 3)));

// 2. Simpan atau perbarui data siswa ke tbl_siswa
$stmt = $conn->prepare("INSERT INTO tbl_siswa (nama, jkel, var1, var2, var3, var4, var5, cluster) VALUES (?, ?, ?, ?, ?, ?, ?, 1)");
$stmt->bind_param("ssiiiii", $nama, $jkel, $scorePaskibra, $scoreBasket, $scoreKarate, $scorePadus, $scorePramuka);

if (!$stmt->execute()) {
    echo json_encode(["status" => "error", "message" => "Gagal menyimpan siswa: " . $stmt->error]);
    exit;
}
$siswaId = $stmt->insert_id;
$stmt->close();

// 3. Simpan jawaban detail ke tbl_respon_kuisioner
$stmtQ = $conn->prepare("INSERT INTO tbl_respon_kuisioner 
    (siswa_id, nama, jkel, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18, q19, q20) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmtQ->bind_param("issiiiiiiiiiiiiiiiiiiii", 
    $siswaId, $nama, $jkel,
    $q[1], $q[2], $q[3], $q[4], $q[5], $q[6], $q[7], $q[8], $q[9], $q[10],
    $q[11], $q[12], $q[13], $q[14], $q[15], $q[16], $q[17], $q[18], $q[19], $q[20]
);
$stmtQ->execute();
$stmtQ->close();

// 4. Sinkronisasi nilai siswa dengan seluruh ekskul aktif yang ada di tbl_ekskul
$resEkskul = $conn->query("SELECT id, nama_ekskul FROM tbl_ekskul ORDER BY id ASC");
if ($resEkskul) {
    while($ek = $resEkskul->fetch_assoc()) {
        $ekId = $ek['id'];
        $ekName = strtoupper($ek['nama_ekskul']);
        $nilai = 0;

        if (strpos($ekName, 'PASKIB') !== false) {
            $nilai = $scorePaskibra;
        } elseif (strpos($ekName, 'BASKET') !== false) {
            $nilai = $scoreBasket;
        } elseif (strpos($ekName, 'KARATE') !== false || strpos($ekName, 'SILAT') !== false || strpos($ekName, 'BELA DIRI') !== false) {
            $nilai = $scoreKarate;
        } elseif (strpos($ekName, 'PADUAN') !== false || strpos($ekName, 'SUARA') !== false || strpos($ekName, 'MUSIK') !== false) {
            $nilai = $scorePadus;
        } elseif (strpos($ekName, 'PRAMUKA') !== false || strpos($ekName, 'PMR') !== false || strpos($ekName, 'ALAM') !== false) {
            $nilai = $scorePramuka;
        } else {
            // Ekskul lainnya: ambil rata-rata preferensi
            $nilai = intval(round(($scorePaskibra + $scoreBasket + $scoreKarate + $scorePadus + $scorePramuka) / 5));
        }

        $conn->query("INSERT INTO tbl_nilai_siswa_ekskul (siswa_id, ekskul_id, nilai) 
                      VALUES ($siswaId, $ekId, $nilai) 
                      ON DUPLICATE KEY UPDATE nilai = $nilai");
    }
}

// 5. Jalankan penyesuaian clustering K-Means otomatis tanpa output ganda
if (!defined('KMEANS_NO_ECHO')) {
    define('KMEANS_NO_ECHO', true);
}
include_once 'kmeans.php';

echo json_encode([
    "status" => "success",
    "message" => "Jawaban kuisioner tersimpan, nilai minat terhitung otomatis dan tersinkronisasi dengan seluruh ekstrakurikuler.",
    "siswa_id" => $siswaId,
    "scores" => [
        "Paskibra" => $scorePaskibra,
        "Basket" => $scoreBasket,
        "Karate" => $scoreKarate,
        "Paduan Suara" => $scorePadus,
        "Pramuka" => $scorePramuka
    ]
]);
?>
