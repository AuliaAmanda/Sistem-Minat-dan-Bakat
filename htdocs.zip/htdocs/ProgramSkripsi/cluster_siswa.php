<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Input Data Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Custom styles for better appearance */
        .form-container {
            transition: all 0.3s ease;
        }
        .form-input:focus {
            box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5);
        }
        .btn-hover:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }
        th {
            position: sticky;
            top: 0;
            background-color: #f8fafc;
            z-index: 10;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen container mx-auto px-4 py-8">
        
        <!-- Tabel Data Siswa -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="bg-blue-600 px-6 py-4">
                <h2 class="text-xl font-bold text-white">Daftar Data Siswa</h2>
            </div>
            
            <div class="overflow-x-auto p-6">
                <table id="studentsTable" class="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jenis Kelamin</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cluster</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <!-- Data akan ditambahkan melalui JavaScript -->
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="px-6 py-4 border-t border-gray-200">
                <div class="flex items-center justify-between">
                    <div class="text-sm text-gray-700">
                        Menampilkan <span id="startItem">0</span> sampai <span id="endItem">0</span> dari <span id="totalItems">0</span> data
                    </div>
                    <div class="flex space-x-2">
                        <button id="refreshButton" class="px-3 py-1 rounded border border-gray-300 bg-white text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed" >
                            Proses Data
                        </button>
                        <button id="prevPage" class="px-3 py-1 rounded border border-gray-300 bg-white text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            Sebelumnya
                        </button>
                        <button id="nextPage" class="px-3 py-1 rounded border border-gray-300 bg-white text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            Selanjutnya
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        const refreshBtn = document.getElementById("refreshButton");

        refreshBtn.addEventListener("click", function() {
            fetch('kmeans.php')
                .then(response => response.json())
                .catch(error => console.error('Error fetching users:', error));
        
            window.location.reload(); // Or window.location.reload(true) for a forced reload
        });
    </script>

    <?php

            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "skripsi";

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);

            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            echo "Connected successfully (MySQLi Procedural)";

            $sql = "SELECT id,nama,jkel,cluster FROM tbl_siswa"; // Select specific columns

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    $dataPoints[] = $row;
                }
            } else {
                echo "0 results";
            } 

            //print_r($dataPoints);
            echo json_encode($dataPoints);
            mysqli_close($conn);
            
    ?>

    <script>
        // In-memory storage for students data
        let students = [];
        let currentPage = 1;
        const itemsPerPage = 5;
        
        const studentsTable = document.getElementById('studentsTable').getElementsByTagName('tbody')[0];
        const prevPageBtn = document.getElementById('prevPage');
        const nextPageBtn = document.getElementById('nextPage');
        const startItemSpan = document.getElementById('startItem');
        const endItemSpan = document.getElementById('endItem');
        const totalItemsSpan = document.getElementById('totalItems');

        // Event Listeners
        prevPageBtn.addEventListener('click', goToPrevPage);
        nextPageBtn.addEventListener('click', goToNextPage);
        
        // Demo data (remove in production)
 //       addDemoData();
            students = <?php echo json_encode($dataPoints); ?>;
            console.log(students);
        renderTable();
        
        // Functions
        
        function renderTable() {
            // Clear table
            studentsTable.innerHTML = '';
            
            // Calculate pagination
            const totalItems = students.length;
            const totalPages = Math.ceil(totalItems / itemsPerPage);
            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = Math.min(startIndex + itemsPerPage, totalItems);
            
            // Update pagination info
            startItemSpan.textContent = startIndex + 1;
            endItemSpan.textContent = endIndex;
            totalItemsSpan.textContent = totalItems;
            
            // Disable/enable pagination buttons
            prevPageBtn.disabled = currentPage <= 1;
            nextPageBtn.disabled = currentPage >= totalPages;
            
            // Add rows to table
            const displayedStudents = students.slice(startIndex, endIndex);
            
            displayedStudents.forEach(student => {
                const row = studentsTable.insertRow();
                
                // Other cells
                row.insertCell(0).textContent = student.id;
                row.insertCell(1).textContent = student.nama;
                row.insertCell(2).textContent = student.jkel === 'L' ? 'Laki-laki' : 'Perempuan';
                row.insertCell(3).textContent = student.cluster;
                
            });
        }
        
        function goToPrevPage() {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
            }
        }
        
        function goToNextPage() {
            const totalPages = Math.ceil(students.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                renderTable();
            }
        }
                      
        function addDemoData() {
            const demoStudents = [
                {
                    id: 1,
                    nama: 'Andi Susanto',
                    jenis_kelamin: 'L',
                    cluster: '1'
                },
                {
                    id: 2,
                    nama: 'Budi Raharjo',
                    jenis_kelamin: 'L',
                    cluster: '3'
                },
                {
                    id: 3,
                    nama: 'Citra Dewi',
                    jenis_kelamin: 'P',
                    cluster: '5'
                }
            ];

            
            students = [...demoStudents];
        }
    </script>
</body>
</html>

