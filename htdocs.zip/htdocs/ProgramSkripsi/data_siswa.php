<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Input Data Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Custom styles for better appearance */
        .form-container {
            transition: all 0.3s ease;
        }
        .form-input:focus {
            box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5);
        }
        .btn-hover:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }
        th {
            position: sticky;
            top: 0;
            background-color: #f8fafc;
            z-index: 10;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen container mx-auto px-4 py-8">
        <div class="bg-white rounded-xl shadow-lg overflow-hidden mb-8 form-container">
            <div class="bg-blue-600 px-6 py-4">
                <h1 class="text-2xl font-bold text-white">Form Input Data Siswa</h1>
            </div>
            
            <div class="p-6">
                <form id="studentForm" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="nis" class="block text-sm font-medium text-gray-700 mb-1">NIS (Nomor Induk Siswa)</label>
                            <input type="text" id="nis" name="nis" required
                                class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-blue-500 form-input"
                                placeholder="Masukkan NIS">
                        </div>
                        
                        <div>
                            <label for="nama" class="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap</label>
                            <input type="text" id="nama" name="nama" required
                                class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-blue-500 form-input"
                                placeholder="Masukkan nama lengkap">
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label for="kelas" class="block text-sm font-medium text-gray-700 mb-1">Kelas</label>
                            <select id="kelas" name="kelas" required
                                class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-blue-500 form-input">
                                <option value="" disabled selected>Pilih kelas</option>
                                <option value="X">Kelas X</option>
                                <option value="XI">Kelas XI</option>
                                <option value="XII">Kelas XII</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="jurusan" class="block text-sm font-medium text-gray-700 mb-1">Jurusan</label>
                            <select id="jurusan" name="jurusan" required
                                class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-blue-500 form-input">
                                <option value="" disabled selected>Pilih jurusan</option>
                                <option value="IPA">IPA</option>
                                <option value="IPS">IPS</option>
                                <option value="Bahasa">Bahasa</option>
                                <option value="Agama">Agama</option>
                                <option value="Teknik">Teknik</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="jenis_kelamin" class="block text-sm font-medium text-gray-700 mb-1">Jenis Kelamin</label>
                            <select id="jenis_kelamin" name="jenis_kelamin" required
                                class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-blue-500 form-input">
                                <option value="" disabled selected>Pilih jenis kelamin</option>
                                <option value="L">Laki-laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                        </div>
                    </div>
                    
                    <div>
                        <label for="alamat" class="block text-sm font-medium text-gray-700 mb-1">Alamat</label>
                        <textarea id="alamat" name="alamat" rows="3"
                            class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-blue-500 form-input"
                            placeholder="Masukkan alamat lengkap"></textarea>
                    </div>
                    
                    <div>
                        <label for="foto" class="block text-sm font-medium text-gray-700 mb-1">Foto Siswa</label>
                        <div class="flex items-center space-x-4">
                            <div class="flex-1">
                                <input type="file" id="foto" name="foto" accept="image/*"
                                    class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-blue-500 form-input">
                            </div>
                            <div class="w-16 h-16 rounded-full border-2 border-gray-300 overflow-hidden">
                                <img src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/1eff7de9-aced-480d-a655-f8a3021f131e.png" alt="Preview foto siswa" id="fotoPreview" class="w-full h-full object-cover">
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-4 pt-4">
                        <button type="reset" class="px-6 py-2 rounded-lg border border-gray-300 bg-gray-100 text-gray-700 hover:bg-gray-200 transition btn-hover">
                            Reset Form
                        </button>
                        <button type="submit" class="px-6 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition btn-hover">
                            Simpan Data
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Tabel Data Siswa -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="bg-blue-600 px-6 py-4">
                <h2 class="text-xl font-bold text-white">Daftar Data Siswa</h2>
            </div>
            
            <div class="overflow-x-auto p-6">
                <table id="studentsTable" class="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Foto</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">NIS</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kelas</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jurusan</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jenis Kelamin</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Alamat</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <!-- Data akan ditambahkan melalui JavaScript -->
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="px-6 py-4 border-t border-gray-200">
                <div class="flex items-center justify-between">
                    <div class="text-sm text-gray-700">
                        Menampilkan <span id="startItem">0</span> sampai <span id="endItem">0</span> dari <span id="totalItems">0</span> data
                    </div>
                    <div class="flex space-x-2">
                        <button id="prevPage" class="px-3 py-1 rounded border border-gray-300 bg-white text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            Sebelumnya
                        </button>
                        <button id="nextPage" class="px-3 py-1 rounded border border-gray-300 bg-white text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            Selanjutnya
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // In-memory storage for students data
        let students = [];
        let currentPage = 1;
        const itemsPerPage = 5;
        
        // DOM elements
        const studentForm = document.getElementById('studentForm');
        const studentsTable = document.getElementById('studentsTable').getElementsByTagName('tbody')[0];
        const fotoInput = document.getElementById('foto');
        const fotoPreview = document.getElementById('fotoPreview');
        const prevPageBtn = document.getElementById('prevPage');
        const nextPageBtn = document.getElementById('nextPage');
        const startItemSpan = document.getElementById('startItem');
        const endItemSpan = document.getElementById('endItem');
        const totalItemsSpan = document.getElementById('totalItems');
        
        // Event Listeners
        studentForm.addEventListener('submit', handleFormSubmit);
        fotoInput.addEventListener('change', handleFotoChange);
        prevPageBtn.addEventListener('click', goToPrevPage);
        nextPageBtn.addEventListener('click', goToNextPage);
        
        // Demo data (remove in production)
        addDemoData();
        renderTable();
        
        // Functions
        function handleFotoChange(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    fotoPreview.src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        }
        
        function handleFormSubmit(event) {
            event.preventDefault();
            
            const formData = new FormData(studentForm);
            
            // Create student object
            const student = {
                id: Date.now(),
                nis: formData.get('nis'),
                nama: formData.get('nama'),
                kelas: formData.get('kelas'),
                jurusan: formData.get('jurusan'),
                jenis_kelamin: formData.get('jenis_kelamin'),
                alamat: formData.get('alamat'),
                foto: fotoPreview.src
            };
            
            // Add to students array
            students.push(student);
            
            // Reset form
            studentForm.reset();
            fotoPreview.src = "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/29f18892-ffe9-41ac-9ff4-b8db9bdf8895.png";
            
            // Re-render table
            renderTable();
            
            // Show success message
            alert('Data siswa berhasil disimpan!');
        }
        
        function renderTable() {
            // Clear table
            studentsTable.innerHTML = '';
            
            // Calculate pagination
            const totalItems = students.length;
            const totalPages = Math.ceil(totalItems / itemsPerPage);
            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = Math.min(startIndex + itemsPerPage, totalItems);
            
            // Update pagination info
            startItemSpan.textContent = startIndex + 1;
            endItemSpan.textContent = endIndex;
            totalItemsSpan.textContent = totalItems;
            
            // Disable/enable pagination buttons
            prevPageBtn.disabled = currentPage <= 1;
            nextPageBtn.disabled = currentPage >= totalPages;
            
            // Add rows to table
            const displayedStudents = students.slice(startIndex, endIndex);
            
            displayedStudents.forEach(student => {
                const row = studentsTable.insertRow();
                
                // Foto
                const fotoCell = row.insertCell(0);
                fotoCell.className = "px-6 py-4 whitespace-nowrap";
                fotoCell.innerHTML = `<div class="w-10 h-10 rounded-full overflow-hidden">
                    <img src="${student.foto}" alt="Foto siswa ${student.nama}" class="w-full h-full object-cover">
                </div>`;
                
                // Other cells
                row.insertCell(1).textContent = student.nis;
                row.insertCell(2).textContent = student.nama;
                row.insertCell(3).textContent = student.kelas;
                row.insertCell(4).textContent = student.jurusan;
                row.insertCell(5).textContent = student.jenis_kelamin === 'L' ? 'Laki-laki' : 'Perempuan';
                row.insertCell(6).textContent = student.alamat;
                
                // Action cell
                const actionCell = row.insertCell(7);
                actionCell.className = "px-6 py-4 whitespace-nowrap text-sm font-medium";
                actionCell.innerHTML = `
                    <button onclick="editStudent(${student.id})" class="text-blue-600 hover:text-blue-900 mr-3">Edit</button>
                    <button onclick="deleteStudent(${student.id})" class="text-red-600 hover:text-red-900">Hapus</button>
                `;
            });
        }
        
        function goToPrevPage() {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
            }
        }
        
        function goToNextPage() {
            const totalPages = Math.ceil(students.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                renderTable();
            }
        }
        
        // Make functions available globally for button actions
        window.editStudent = function(id) {
            const student = students.find(s => s.id === id);
            if (student) {
                // Fill form with student data
                document.getElementById('nis').value = student.nis;
                document.getElementById('nama').value = student.nama;
                document.getElementById('kelas').value = student.kelas;
                document.getElementById('jurusan').value = student.jurusan;
                document.getElementById('jenis_kelamin').value = student.jenis_kelamin;
                document.getElementById('alamat').value = student.alamat;
                fotoPreview.src = student.foto;
                
                // Remove the student from array (will be re-added on submit)
                students = students.filter(s => s.id !== id);
                
                // Scroll to form
                document.querySelector('.form-container').scrollIntoView({ behavior: 'smooth' });
            }
        };
        
        window.deleteStudent = function(id) {
            if (confirm('Apakah Anda yakin ingin menghapus data siswa ini?')) {
                students = students.filter(s => s.id !== id);
                renderTable();
                alert('Data siswa berhasil dihapus!');
            }
        };
        
        function addDemoData() {
            const demoStudents = [
                {
                    id: 1,
                    nis: '20220001',
                    nama: 'Andi Susanto',
                    kelas: 'X',
                    jurusan: 'IPA',
                    jenis_kelamin: 'L',
                    alamat: 'Jl. Merdeka No. 10, Jakarta',
                    foto: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/d007f806-4118-49b9-ac40-aa5e27add4c7.png'
                },
                {
                    id: 2,
                    nis: '20220002',
                    nama: 'Budi Raharjo',
                    kelas: 'XI',
                    jurusan: 'IPS',
                    jenis_kelamin: 'L',
                    alamat: 'Jl. Sudirman No. 45, Bandung',
                    foto: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/b4089df5-fe4d-4ccc-93e5-13076f446f1c.png'
                },
                {
                    id: 3,
                    nis: '20220003',
                    nama: 'Citra Dewi',
                    kelas: 'XII',
                    jurusan: 'Bahasa',
                    jenis_kelamin: 'P',
                    alamat: 'Jl. Gatot Subroto No. 23, Surabaya',
                    foto: 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/8578996d-6efc-48d2-a50e-36f95cb96a80.png'
                }
            ];
            
            students = [...demoStudents];
        }
    </script>
</body>
</html>

