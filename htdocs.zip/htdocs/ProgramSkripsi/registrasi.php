<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Isi Data Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .form-container {
            transition: all 0.3s ease;
        }
        .form-input:focus {
            box-shadow: 0 0 0 2px rgba(79, 70, 229, 0.5);
        }
        .btn-hover:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }
        th {
            position: sticky;
            top: 0;
            background-color: #f8fafc;
            z-index: 10;
        }
        .ekskul-input {
            display: none;
        }
        .ekskul-checkbox:checked ~ .ekskul-input {
            display: block;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen container mx-auto px-4 py-8">
        <!-- Form Registrasi -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden mb-8 form-container">
            <div class="bg-indigo-600 px-6 py-4">
                <h1 class="text-2xl font-bold text-white">Form Registrasi Siswa</h1>
            </div>
            
            <div class="p-6">
                <form id="registrasiForm" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="id_siswa" class="block text-sm font-medium text-gray-700 mb-1">ID Siswa</label>
                            <input type="text" id="id_siswa" name="id_siswa" 
                                class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 form-input"
                                placeholder="Ex: SIS001">
                        </div>
                        
                        <div>
                            <label for="nama_siswa" class="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap</label>
                            <input type="text" id="nama_siswa" name="nama_siswa" required
                                class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 form-input"
                                placeholder="Masukkan nama siswa">
                        </div>
                    </div>
                    
                    <div>
                        <label for="jenis_kelamin" class="block text-sm font-medium text-gray-700 mb-1">Jenis Kelamin</label>
                        <select id="jenis_kelamin" name="jenis_kelamin" required
                            class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 form-input">
                            <option value="" disabled selected>Pilih jenis kelamin</option>
                            <option value="L">Laki-laki</option>
                            <option value="P">Perempuan</option>
                        </select>
                    </div>
                    
                    <div class="space-y-4">
                        <h3 class="text-lg font-medium text-gray-900">Nilai Ekstrakurikuler</h3>
                        <small class="text-gray-500">Isi nilai sesuai hasil kuisioner</small>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <!-- Paskibra -->
                            <div class="space-y-2">
                                <div class="flex items-center">

                                    <label for="nilai_paskibra" class="block text-sm font-medium text-gray-700 mb-1">Nilai Paskibra</label>
                                    <input type="number" id="nilai_paskibra" name="nilai_paskibra" min="0" max="20"
                                        class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 form-input"
                                        placeholder="0-20">
                                </div>
                            </div>
                            
                            <!-- Basket -->
                            <div class="space-y-2">
                                <div class="flex items-center">
                                    
                                    <label for="nilai_basket" class="block text-sm font-medium text-gray-700 mb-1">Nilai Basket</label>
                                    <input type="number" id="nilai_basket" name="nilai_basket" min="0" max="20"
                                        class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 form-input"
                                        placeholder="0-20">
                                </div>
                            </div>
                            
                            <!-- Karate -->
                            <div class="space-y-2">
                                <div class="flex items-center">
                                  
                                    <label for="nilai_karate" class="block text-sm font-medium text-gray-700 mb-1">Nilai Karate</label>
                                    <input type="number" id="nilai_karate" name="nilai_karate" min="0" max="20"
                                        class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 form-input"
                                        placeholder="0-20">
                                </div>
                            </div>
                            
                            <!-- Paduan Suara -->
                            <div class="space-y-2">
                                <div class="flex items-center">
                                   
                                    <label for="nilai_paduan_suara" class="block text-sm font-medium text-gray-700 mb-1">Nilai Paduan Suara</label>
                                    <input type="number" id="nilai_paduan_suara" name="nilai_paduan_suara" min="0" max=20"
                                        class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 form-input"
                                        placeholder="0-20">
                                </div>
                            </div>
                            
                            <!-- Pramuka -->
                            <div class="space-y-2">
                                <div class="flex items-center">
                                   
                                    <label for="nilai_pramuka" class="block text-sm font-medium text-gray-700 mb-1">Nilai Pramuka</label>
                                    <input type="number" id="nilai_pramuka" name="nilai_pramuka" min="0" max="20"
                                        class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 form-input"
                                        placeholder="0-20">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-4 pt-4">
                        <button type="reset" class="px-6 py-2 rounded-lg border border-gray-300 bg-gray-100 text-gray-700 hover:bg-gray-200 transition btn-hover">
                            Reset Form
                        </button>
                        <button type="submit" class="px-6 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition btn-hover">
                            Daftar
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Tabel Data Siswa -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="bg-indigo-600 px-6 py-4">
                <h2 class="text-xl font-bold text-white">Daftar Siswa Terdaftar</h2>
            </div>
            
            <div class="overflow-x-auto p-6">
                <table id="siswaTable" class="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jenis Kelamin</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ekskul 1</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ekskul 2</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ekskul 3</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ekskul 4</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ekskul 5</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <!-- Data akan diisi oleh JavaScript -->
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="px-6 py-4 border-t border-gray-200">
                <div class="flex items-center justify-between">
                    <div class="text-sm text-gray-700">
                        Menampilkan <span id="siswaStartItem">1</span> sampai <span id="siswaEndItem">2</span> dari <span id="siswaTotalItems">2</span> data
                    </div>
                    <div class="flex space-x-2">
                        <button id="siswaPrevPage" class="px-3 py-1 rounded border border-gray-300 bg-white text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            Sebelumnya
                        </button>
                        <button id="siswaNextPage" class="px-3 py-1 rounded border border-gray-300 bg-white text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            Selanjutnya
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php

            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "skripsi";

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);

            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            //echo "Connected successfully (MySQLi Procedural)";

            $sql = "SELECT id,nama,jkel,var1,var2,var3,var4,var5 FROM tbl_siswa"; // Select specific columns

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    $dataPoints[] = $row;
                }
            } else {
                echo "0 results";
            } 

            //print_r($dataPoints);
            //echo json_encode($dataPoints);
            mysqli_close($conn);
            
    ?>

    <script>
        // Data siswa
        let siswaData = [];
        let currentSiswaPage = 1;
        const siswaPerPage = 5;
        
        // DOM Elements
        const registrasiForm = document.getElementById('registrasiForm');
        const siswaTable = document.getElementById('siswaTable').getElementsByTagName('tbody')[0];
        const siswaPrevBtn = document.getElementById('siswaPrevPage');
        const siswaNextBtn = document.getElementById('siswaNextPage');
        const siswaStartSpan = document.getElementById('siswaStartItem');
        const siswaEndSpan = document.getElementById('siswaEndItem');
        const siswaTotalSpan = document.getElementById('siswaTotalItems');
        
        // Event Listeners
        registrasiForm.addEventListener('submit', handleRegistrasiSubmit);
        siswaPrevBtn.addEventListener('click', goToPrevSiswaPage);
        siswaNextBtn.addEventListener('click', goToNextSiswaPage);
      
        
        // Data contoh (bisa dihapus di production)
        //addDemoSiswaData();
        siswaData = <?php echo json_encode($dataPoints); ?>;
            console.log(siswaData);
        renderSiswaTable();
        
        // Functions
        function handleRegistrasiSubmit(event) {
            event.preventDefault();
            
            const formData = new FormData(registrasiForm);
            
            
            const siswa = {
                id: formData.get('id_siswa'),
                nama: formData.get('nama_siswa'),
                jkel: formData.get('jenis_kelamin'),
                var1: formData.get('nilai_paskibra'),
                var2: formData.get('nilai_basket'),
                var3: formData.get('nilai_karate'),
                var4: formData.get('nilai_paduan_suara'),
                var5: formData.get('nilai_pramuka'),
            };
            console.log(siswa);
            // Cek apakah ID sudah ada untuk edit mode
            //const existingIndex = siswaData.findIndex(s => s.id === siswa.id);
            if (siswa.id != "") {
                siswaData[siswa.id] = siswa;
                fetch('update_data.php', { // Target PHP script
                    method: 'POST',
                    body: formData
                })
                //console.log(data)
                .then(response => response.text())
                .then(data => {
                    console.log(data); // Handle response from PHP
                    // e.g., display success message or error
                })
                .catch(error => {
                    console.error('Error:', error);
                });
                alert('Data siswa berhasil diperbarui!');
            } else {
                siswaData.push(siswa);
                fetch('insert_data.php', { // Target PHP script
                    method: 'POST',
                    body: formData
                })
                //console.log(data)
                .then(response => response.text())
                .then(data => {
                    console.log(data); // Handle response from PHP
                    // e.g., display success message or error
                })
                .catch(error => {
                    console.error('Error:', error);
                });
                alert('Data siswa berhasil ditambahkan!');
            }
            
            // Reset form
            registrasiForm.reset();
            document.querySelectorAll('.ekskul-input').forEach(el => {
                el.style.display = 'none';
            });
            
            // Render ulang tabel
            renderSiswaTable();
        }
        
        function renderSiswaTable() {
            siswaTable.innerHTML = '';
            
            const totalItems = siswaData.length;
            const totalPages = Math.ceil(totalItems / siswaPerPage);
            const startIndex = (currentSiswaPage - 1) * siswaPerPage;
            const endIndex = Math.min(startIndex + siswaPerPage, totalItems);
            
            // Update pagination info
            siswaStartSpan.textContent = startIndex + 1;
            siswaEndSpan.textContent = endIndex;
            siswaTotalSpan.textContent = totalItems;
            
            // Atur tombol pagination
            siswaPrevBtn.disabled = currentSiswaPage <= 1;
            siswaNextBtn.disabled = currentSiswaPage >= totalPages;
            
            // Isi tabel
            const displayedSiswa = siswaData.slice(startIndex, endIndex);
            
            displayedSiswa.forEach(siswa => {
                const row = siswaTable.insertRow();
                
                // ID
                row.insertCell(0).textContent = siswa.id;
                
                // Info siswa
                row.insertCell(1).textContent = siswa.nama;
                row.insertCell(2).textContent = siswa.jkel === 'L' ? 'Laki-laki' : 'Perempuan';
                
                row.insertCell(3).textContent = siswa.var1;
                row.insertCell(4).textContent = siswa.var2;
                row.insertCell(5).textContent = siswa.var3;
                row.insertCell(6).textContent = siswa.var4;
                row.insertCell(7).textContent = siswa.var5;
                
                // Tombol aksi
                const actionCell = row.insertCell(8);
                actionCell.className = "px-6 py-4 whitespace-nowrap text-sm font-medium";
                actionCell.innerHTML = `
                    <button onclick="editSiswa('${siswa.id}')" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</button>
                    <button onclick="deleteSiswa('${siswa.id}')" class="text-red-600 hover:text-red-900">Hapus</button>
                `;
            });
        }
        
        function goToPrevSiswaPage() {
            if (currentSiswaPage > 1) {
                currentSiswaPage--;
                renderSiswaTable();
            }
        }
        
        function goToNextSiswaPage() {
            const totalPages = Math.ceil(siswaData.length / siswaPerPage);
            if (currentSiswaPage < totalPages) {
                currentSiswaPage++;
                renderSiswaTable();
            }
        }
        
        // Fungsi global untuk aksi
        window.editSiswa = function(id) {
            const siswa = siswaData.find(s => s.id === id);
            if (siswa) {
                // Isi form dengan data siswa
                document.getElementById('id_siswa').value = siswa.id;
                document.getElementById('nama_siswa').value = siswa.nama;
                document.getElementById('jenis_kelamin').value = siswa.jkel;
                
                document.getElementById('nilai_paskibra').value = siswa.var1;
                document.getElementById('nilai_basket').value = siswa.var2;
                document.getElementById('nilai_karate').value = siswa.var3;
                document.getElementById('nilai_paduan_suara').value = siswa.var4;
                document.getElementById('nilai_pramuka').value = siswa.var5;
                
                
                // Hapus dari array (akan ditambahkan kembali saat submit)
                siswaData = siswaData.filter(s => s.id !== id);
                
                // Scroll ke form
                document.querySelector('.form-container').scrollIntoView({ behavior: 'smooth' });
            }
        };
        
        window.deleteSiswa = function(id) {
            if (confirm('Apakah Anda yakin ingin menghapus data siswa ini?')) {
                siswaData = siswaData.filter(s => s.id !== id);
                renderSiswaTable();
                alert('Data siswa berhasil dihapus!');
            }
        };
        
        function addDemoSiswaData() {
            const demoSiswa = [
                {
                    id: 'SIS001',
                    nama: 'Andi Wijaya',
                    jenis_kelamin: 'L',
                    ekskul: [
                        { nama: 'Paskibra', nilai: '85' },
                        { nama: 'Basket', nilai: '78' }
                    ]
                },
                {
                    id: 'SIS002',
                    nama: 'Budi Santoso',
                    jenis_kelamin: 'L',
                    ekskul: [
                        { nama: 'Karate', nilai: '90' },
                        { nama: 'Pramuka', nilai: '82' }
                    ]
                },
                {
                    id: 'SIS003',
                    nama: 'Citra Dewi',
                    jenis_kelamin: 'P',
                    ekskul: [
                        { nama: 'Paduan Suara', nilai: '88' },
                        { nama: 'Pramuka', nilai: '85' }
                    ]
                },
                {
                    id: 'SIS004',
                    nama: 'Dian Permata',
                    jenis_kelamin: 'P',
                    ekskul: [
                        { nama: 'Paskibra', nilai: '92' },
                        { nama: 'Paduan Suara', nilai: '87' }
                    ]
                },
                {
                    id: 'SIS005',
                    nama: 'Eko Pratama',
                    jenis_kelamin: 'L',
                    ekskul: [
                        { nama: 'Basket', nilai: '80' },
                        { nama: 'Karate', nilai: '85' }
                    ]
                }
            ];
            
            siswaData = [...demoSiswa];
        }
    </script>
</body>
</html>
