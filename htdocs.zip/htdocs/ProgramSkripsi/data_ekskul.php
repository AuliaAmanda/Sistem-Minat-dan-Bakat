<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Input Data Ekstrakurikuler</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .form-container {
            transition: all 0.3s ease;
        }
        .form-input:focus {
            box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5);
        }
        .btn-hover:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }
        th {
            position: sticky;
            top: 0;
            background-color: #f8fafc;
            z-index: 10;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen container mx-auto px-4 py-8">
        <!-- Form Input -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden mb-8 form-container">
            <div class="bg-green-600 px-6 py-4">
                <h1 class="text-2xl font-bold text-white">Form Input Data Ekstrakurikuler</h1>
            </div>
            
            <div class="p-6">
                <form id="ekskulForm" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="id_ekskul" class="block text-sm font-medium text-gray-700 mb-1">ID Ekstrakurikuler</label>
                            <input type="text" id="id_ekskul" name="id_ekskul" required
                                class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-green-500 focus:ring-green-500 form-input"
                                placeholder="Ex: EKS001">
                        </div>
                        
                        <div>
                            <label for="nama_ekskul" class="block text-sm font-medium text-gray-700 mb-1">Nama Ekstrakurikuler</label>
                            <input type="text" id="nama_ekskul" name="nama_ekskul" required
                                class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-green-500 focus:ring-green-500 form-input"
                                placeholder="Masukkan nama ekskul">
                        </div>
                    </div>
                    
                    <div>
                        <label for="keterangan" class="block text-sm font-medium text-gray-700 mb-1">Keterangan</label>
                        <textarea id="keterangan" name="keterangan" rows="3"
                            class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-green-500 focus:ring-green-500 form-input"
                            placeholder="Deskripsi kegiatan, jadwal, persyaratan, dll"></textarea>
                    </div>
                    
                    <div class="flex justify-end space-x-4 pt-4">
                        <button type="reset" class="px-6 py-2 rounded-lg border border-gray-300 bg-gray-100 text-gray-700 hover:bg-gray-200 transition btn-hover">
                            Reset Form
                        </button>
                        <button type="submit" class="px-6 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 transition btn-hover">
                            Simpan Data
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Tabel Data -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="bg-green-600 px-6 py-4">
                <h2 class="text-xl font-bold text-white">Daftar Ekstrakurikuler</h2>
            </div>
            
            <div class="overflow-x-auto p-6">
                <table id="ekskulTable" class="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama Ekstrakurikuler</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Keterangan</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <!-- Data akan diisi oleh JavaScript -->
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="px-6 py-4 border-t border-gray-200">
                <div class="flex items-center justify-between">
                    <div class="text-sm text-gray-700">
                        Menampilkan <span id="ekskulStartItem">0</span> sampai <span id="ekskulEndItem">0</span> dari <span id="ekskulTotalItems">0</span> data
                    </div>
                    <div class="flex space-x-2">
                        <button id="ekskulPrevPage" class="px-3 py-1 rounded border border-gray-300 bg-white text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            Sebelumnya
                        </button>
                        <button id="ekskulNextPage" class="px-3 py-1 rounded border border-gray-300 bg-white text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            Selanjutnya
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Data ekstrakurikuler
        let ekskulData = [];
        let currentEkskulPage = 1;
        const ekskulPerPage = 5;
        
        // DOM Elements
        const ekskulForm = document.getElementById('ekskulForm');
        const ekskulTable = document.getElementById('ekskulTable').getElementsByTagName('tbody')[0];
        const ekskulPrevBtn = document.getElementById('ekskulPrevPage');
        const ekskulNextBtn = document.getElementById('ekskulNextPage');
        const ekskulStartSpan = document.getElementById('ekskulStartItem');
        const ekskulEndSpan = document.getElementById('ekskulEndItem');
        const ekskulTotalSpan = document.getElementById('ekskulTotalItems');
        
        // Event Listeners
        ekskulForm.addEventListener('submit', handleEkskulSubmit);
        ekskulPrevBtn.addEventListener('click', goToPrevEkskulPage);
        ekskulNextBtn.addEventListener('click', goToNextEkskulPage);
        
        // Data contoh (bisa dihapus di production)
        addDemoEkskulData();
        renderEkskulTable();
        
        // Functions
        function handleEkskulSubmit(event) {
            event.preventDefault();
            
            const formData = new FormData(ekskulForm);
            
            const ekskul = {
                id: formData.get('id_ekskul'),
                nama: formData.get('nama_ekskul'),
                keterangan: formData.get('keterangan')
            };
            
            // Cek apakah ID sudah ada untuk edit mode
            const existingIndex = ekskulData.findIndex(e => e.id === ekskul.id);
            if (existingIndex >= 0) {
                ekskulData[existingIndex] = ekskul;
                alert('Data ekskul berhasil diperbarui!');
            } else {
                ekskulData.push(ekskul);
                alert('Data ekskul berhasil ditambahkan!');
            }
            
            // Reset form
            ekskulForm.reset();
            
            // Render ulang tabel
            renderEkskulTable();
        }
        
        function renderEkskulTable() {
            ekskulTable.innerHTML = '';
            
            const totalItems = ekskulData.length;
            const totalPages = Math.ceil(totalItems / ekskulPerPage);
            const startIndex = (currentEkskulPage - 1) * ekskulPerPage;
            const endIndex = Math.min(startIndex + ekskulPerPage, totalItems);
            
            // Update pagination info
            ekskulStartSpan.textContent = startIndex + 1;
            ekskulEndSpan.textContent = endIndex;
            ekskulTotalSpan.textContent = totalItems;
            
            // Atur tombol pagination
            ekskulPrevBtn.disabled = currentEkskulPage <= 1;
            ekskulNextBtn.disabled = currentEkskulPage >= totalPages;
            
            // Isi tabel
            const displayedEkskul = ekskulData.slice(startIndex, endIndex);
            
            displayedEkskul.forEach(ekskul => {
                const row = ekskulTable.insertRow();
                
                row.insertCell(0).textContent = ekskul.id;
                row.insertCell(1).textContent = ekskul.nama;
                row.insertCell(2).textContent = ekskul.keterangan;
                
                // Tombol aksi
                const actionCell = row.insertCell(3);
                actionCell.className = "px-6 py-4 whitespace-nowrap text-sm font-medium";
                actionCell.innerHTML = `
                    <button onclick="editEkskul('${ekskul.id}')" class="text-green-600 hover:text-green-900 mr-3">Edit</button>
                    <button onclick="deleteEkskul('${ekskul.id}')" class="text-red-600 hover:text-red-900">Hapus</button>
                `;
            });
        }
        
        function goToPrevEkskulPage() {
            if (currentEkskulPage > 1) {
                currentEkskulPage--;
                renderEkskulTable();
            }
        }
        
        function goToNextEkskulPage() {
            const totalPages = Math.ceil(ekskulData.length / ekskulPerPage);
            if (currentEkskulPage < totalPages) {
                currentEkskulPage++;
                renderEkskulTable();
            }
        }
        
        // Fungsi global untuk aksi
        window.editEkskul = function(id) {
            const ekskul = ekskulData.find(e => e.id === id);
            if (ekskul) {
                document.getElementById('id_ekskul').value = ekskul.id;
                document.getElementById('nama_ekskul').value = ekskul.nama;
                document.getElementById('keterangan').value = ekskul.keterangan;
                
                // Hapus dari array (akan ditambahkan kembali saat submit)
                ekskulData = ekskulData.filter(e => e.id !== id);
                
                // Scroll ke form
                document.querySelector('.form-container').scrollIntoView({ behavior: 'smooth' });
            }
        };
        
        window.deleteEkskul = function(id) {
            if (confirm('Apakah Anda yakin ingin menghapus data ekskul ini?')) {
                ekskulData = ekskulData.filter(e => e.id !== id);
                renderEkskulTable();
                alert('Data ekskul berhasil dihapus!');
            }
        };
        
        function addDemoEkskulData() {
            const demoEkskul = [
                {
                    id: 'EKS001',
                    nama: 'Paskibra',
                    keterangan: 'Latihan setiap Sabtu pagi, wajib mengikuti upacara'
                },
                {
                    id: 'EKS002',
                    nama: 'Futsal',
                    keterangan: 'Latihan hari Selasa dan Kamis jam 15.30-17.00 di lapangan sekolah'
                },
                {
                    id: 'EKS003',
                    nama: 'Teater',
                    keterangan: 'Latihan rutin setiap Jumat sore, persiapan pentas seni akhir tahun'
                },
                {
                    id: 'EKS004',
                    nama: 'Robotik',
                    keterangan: 'Belajar dasar pemrograman robot, pertemuan setiap Rabu di lab komputer 2'
                },
                {
                    id: 'EKS005',
                    nama: 'Pramuka',
                    keterangan: 'Kegiatan kepanduan setiap Sabtu kedua dan keempat setiap bulan'
                }
            ];
            
            ekskulData = [...demoEkskul];
        }
    </script>
</body>
</html>

```