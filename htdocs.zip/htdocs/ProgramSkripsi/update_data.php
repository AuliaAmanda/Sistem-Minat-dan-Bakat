    <?php
    // update_data.php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "skripsi";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get data from POST request
    $nama = $_POST['nama_siswa'] ?? ''; // Example: assuming 'name' field from form
    $jkel = $_POST['jenis_kelamin'] ?? ''; // Example: assuming 'email' field from form
    $var1 = $_POST['nilai_paskibra'] ?? ''; // Example: assuming 'email' field from form
    $var2 = $_POST['nilai_basket'] ?? ''; // Example: assuming 'email' field from form
    $var3 = $_POST['nilai_karate'] ?? ''; // Example: assuming 'email' field from form
    $var4 = $_POST['nilai_paduan_suara'] ?? ''; // Example: assuming 'email' field from form
    $var5 = $_POST['nilai_pramuka'] ?? ''; // Example: assuming 'email' field from form
    $iddata = $_POST['id_siswa'] ?? '';
    // Prepare and bind
    $stmt = $conn->prepare("update tbl_siswa set nama = ?, jkel = ?, var1 = ?, var2 = ?, var3 = ?, var4 = ?, var5 = ? where id = ? ");
    $stmt->bind_param("ssiiiiii", $nama, $jkel,$var1,$var2,$var3,$var4,$var5,$iddata); // "ss" indicates two string parameters
    console.log($stmt);
    //mysqli_query($con_db, "INSERT into comment(msg,date_added,ip_add) values ('$content','$fptime','$log_ip')");
    // Execute and check
    if ($stmt->execute()) {
        echo "Record updated successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    ?>