-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2025 at 07:24 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skripsi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ekskul`
--

CREATE TABLE `tbl_ekskul` (
  `id` int(11) NOT NULL,
  `kode_ekskul` varchar(7) NOT NULL,
  `nama_ekskul` varchar(25) NOT NULL,
  `jml_anggota` int(11) NOT NULL,
  `nama_pelatih` varchar(30) NOT NULL,
  `keterangan` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_ekskul`
--

INSERT INTO `tbl_ekskul` (`id`, `kode_ekskul`, `nama_ekskul`, `jml_anggota`, `nama_pelatih`, `keterangan`) VALUES
(1, 'EKS001', 'PASKIBRA ', 28, 'Budi Santoso, S.Pd.', 'Program latihan kedisiplinan, baris-berbaris, dan pembinaan karakter. Fokus pada pembentukan mental dan fisik yang disiplin.'),
(2, 'EKS002', 'BASKET', 35, 'Ahmad Rizki, S.Pd.', 'Program olahraga bola basket dengan fokus pada teknik dasar, strategi permainan, dan kerjasama tim. Turnatur rutin diadakan setiap semester.'),
(3, 'EKS003', 'KARATE', 24, 'Surya Dharma, S.Pd.', 'Program bela diri karate dengan kurikulum yang terstruktur. Siswa dapat mengikuti ujian kenaikan tingkat setiap 6 bulan sekali.'),
(4, 'EKS004', 'PADUAN SUARA', 18, 'Dian Sastrowardoyo, S.Sn.', 'Program vokal grup dengan penekanan pada harmonisasi suara, teknik pernapasan, dan ekspresi musikal. Sering tampil dalam acara sekolah dan kompetisi.'),
(5, 'EKS005', 'PRAMUKA', 22, 'Rina Wijaya, S.Pd.', 'Program kepramukaan yang mengajarkan kemandirian, kepemimpinan, dan kecintaan alam. Kegiatan termasuk perkemahan, hiking, dan latihan keterampilan.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_ekskul`
--
ALTER TABLE `tbl_ekskul`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_ekskul`
--
ALTER TABLE `tbl_ekskul`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
