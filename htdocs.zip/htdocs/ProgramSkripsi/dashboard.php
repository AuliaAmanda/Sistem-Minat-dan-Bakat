<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Manajemen Minat dan Bakat</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .btn-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .menu-card {
            transition: all 0.3s ease;
        }
        .menu-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-indigo-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-6 flex flex-col md:flex-row items-center justify-between">
                <div class="flex items-center mb-4 md:mb-0">
                    <i class="fas fa-school text-4xl mr-3"></i>
                    <div>
                        <h1 class="text-2xl font-bold">Minat Bakat</h1>
                        <p class="text-sm opacity-80">Sistem Manajemen Minat dan Bakat</p>
                    </div>
                </div>
                <nav class="flex space-x-1 md:space-x-4">
                    <a href="#" class="px-3 py-2 rounded-md bg-indigo-700 font-medium">
                        <i class="fas fa-home mr-2"></i>Beranda
                    </a>
                </nav>
            </div>
        </header>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-8">
            <!-- Welcome Section -->
            <section class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-800 mb-2">Selamat Datang di Aplikasi</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">
                    Sistem terintegrasi untuk mengelola data siswa, ekstrakurikuler, dan hasil clustering.
                </p>
            </section>

            <!-- Menu Grid -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <!-- Data Siswa Card -->
                <a href="data-siswa.html" class="menu-card bg-white rounded-xl shadow-md overflow-hidden">
                    <div class="p-6 text-center">
                        <div class="bg-blue-100 w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4">
                            <i class="fas fa-users text-blue-600 text-3xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Data Siswa</h3>
                        <p class="text-gray-600 mb-4">Kelola data siswa dan informasi pribadi</p>
                        <button class="btn-hover px-6 py-2 bg-blue-600 text-white rounded-lg transition">
                            Buka <i class="fas fa-arrow-right ml-2"></i>
                        </button>
                    </div>
                </a>

                <!-- Data Ekskul Card -->
                <a href="data-ekskul.html" class="menu-card bg-white rounded-xl shadow-md overflow-hidden">
                    <div class="p-6 text-center">
                        <div class="bg-green-100 w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4">
                            <i class="fas fa-futbol text-green-600 text-3xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Data Ekstrakurikuler</h3>
                        <p class="text-gray-600 mb-4">Kelola kegiatan ekstrakurikuler sekolah</p>
                        <button class="btn-hover px-6 py-2 bg-green-600 text-white rounded-lg transition">
                            Buka <i class="fas fa-arrow-right ml-2"></i>
                        </button>
                    </div>
                </a>

                <!-- Clustering Card -->
                <a href="clustering.html" class="menu-card bg-white rounded-xl shadow-md overflow-hidden">
                    <div class="p-6 text-center">
                        <div class="bg-purple-100 w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4">
                            <i class="fas fa-project-diagram text-purple-600 text-3xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Hasil Clustering</h3>
                        <p class="text-gray-600 mb-4">Analisis pengelompokan minat siswa</p>
                        <button class="btn-hover px-6 py-2 bg-purple-600 text-white rounded-lg transition">
                            Buka <i class="fas fa-arrow-right ml-2"></i>
                        </button>
                    </div>
                </a>
            </div>
        </main>

        <!-- Footer -->
        <footer class="bg-gray-800 text-white py-8">
            <div class="container mx-auto px-4 text-center">
                <p>&copy; 2023 Aplikasi Manajemen Sekolah. All rights reserved.</p>
                <div class="mt-4 flex justify-center space-x-4">
                    <a href="#" class="hover:text-indigo-300">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <a href="#" class="hover:text-indigo-300">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="hover:text-indigo-300">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
        </footer>
    </div>

    <script>
        // Simple script for interactivity
        document.addEventListener('DOMContentLoaded', function() {
            const menuCards = document.querySelectorAll('.menu-card');
            
            menuCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.boxShadow = '0 10px 15px rgba(0, 0, 0, 0.2)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
                });
            });
        });
    </script>
</body>
</html>
