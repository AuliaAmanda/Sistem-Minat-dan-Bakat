<?php

class KMeans
{
    private $data;
    private $k;
    private $centroids;
    private $clusters;

    public function __construct(array $data, int $k)
    {
        $this->data = $data;
        $this->k = $k;
        $this->initializeCentroids();
    }

    private function initializeCentroids()
    {
        // Randomly select k data points as initial centroids
        $randomKeys = array_rand($this->data, $this->k);
        foreach ($randomKeys as $key) {
            $this->centroids[] = $this->data[$key];
        }
    }

    private function calculateDistance(array $point1, array $point2): float
    {
        // Assuming 2D points for simplicity (x, y)
        return sqrt(pow($point1[0] - $point2[0], 2) + pow($point1[1] - $point2[1], 2) + pow($point1[2] - $point2[2], 2)+ pow($point1[3] - $point2[3], 2)+ pow($point1[4] - $point2[4], 2));
    }

    public function solve(int $maxIterations = 100): array
    {
        for ($i = 0; $i < $maxIterations; $i++) {
            $this->clusters = array_fill(0, $this->k, []);
            $changed = false;

            // Assignment step
            foreach ($this->data as $pointIndex => $point) {
                $minDistance = INF;
                $closestCluster = -1;

                foreach ($this->centroids as $centroidIndex => $centroid) {
                    $distance = $this->calculateDistance($point, $centroid);
                    if ($distance < $minDistance) {
                        $minDistance = $distance;
                        $closestCluster = $centroidIndex;
                    }
                }
                $this->clusters[$closestCluster][] = $point;
            }

            // Update step
            $newCentroids = [];
            foreach ($this->clusters as $clusterIndex => $clusterPoints) {
                if (empty($clusterPoints)) {
                    // Handle empty clusters (e.g., re-initialize centroid)
                    $newCentroids[$clusterIndex] = $this->centroids[$clusterIndex]; // Keep old centroid for now
                    continue;
                }
                $sumX = 0;
                $sumY = 0;
                foreach ($clusterPoints as $point) {
                    $sumX += $point[0];
                    $sumY += $point[1];
                }
                $newCentroids[$clusterIndex] = [$sumX / count($clusterPoints), $sumY / count($clusterPoints)];

                // Check for convergence
                if ($this->calculateDistance($newCentroids[$clusterIndex], $this->centroids[$clusterIndex]) > 0.001) {
                    $changed = true;
                }
            }
            $this->centroids = $newCentroids;

            if (!$changed) {
                break; // Converged
            }
        }
        return $this->clusters;
    }
}

// Example Usage:
//$dataPoints = [
//    [4, 12, 10, 8, 7, "beti"], [5, 9, 10, 11, 15, "wina"], [5, 8, 9, 9, 7, "resti"], [8, 8, 10, 11, 15, "joko"], [5, 10, 14, 12, 9, "resa"],
//    [9, 11, 12, 10, 8, "joni"], [10, 12, 10, 8, 2, "wawan"], [12, 10, 8, 9, 3, "dwi"]
//];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "skripsi";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    echo "Connected successfully (MySQLi Procedural)";
    $sql = "SELECT * FROM tbl_siswa"; // Select specific columns
    // Or to select all columns:
    // $sql = "SELECT * FROM MyGuests";

    $result = $conn->query($sql);

if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
           // echo "id: " . $row["id"]. " - Name: " . $row["nama"]. " " . $row["cluster"]. "<br>";
        $dataPoints[] = [$row["var1"],$row["var2"],$row["var3"],$row["var4"],$row["var5"],$row["nama"],$row["id"]];
        }
    } else {
        echo "0 results";
    } 
    //$row_array = $result->fetch_array(MYSQLI_ASSOC); 

    // Now $row_array contains the data from the fetched row
    //print_r($row_array);
    

    //print_r($dataPoints);

$kMeans = new KMeans($dataPoints, 5); // Cluster into 3 groups
$clusters = $kMeans->solve();

echo "Clustered Data:\n";
foreach ($clusters as $clusterIndex => $clusterPoints) {
    echo "Cluster " . ($clusterIndex + 1) . ":\n";
    foreach ($clusterPoints as $point) {
        echo "  (" . $point[5] . ")\n";
        $sql = "UPDATE tbl_siswa SET cluster = " . ($clusterIndex + 1) . " WHERE id = ". $point[6];
        echo $sql;
        if (mysqli_query($conn, $sql)) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }
}
    
mysqli_close($conn);


?>